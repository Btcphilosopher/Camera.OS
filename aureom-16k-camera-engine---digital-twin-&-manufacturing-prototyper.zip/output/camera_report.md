# AUREOM CAMERA ENGINE
## AUREOM 16K DIGITAL TWIN — Canonical Engineering Verification Report
**Camera Model ID:** `AUR-16K-CINEMA-FLAGSHIP`  
**Architecture Spec Status:** **PASSED (COMPLIANT)**  
**Limiting Factor:** `None (Balanced High-Performance Architecture)`  

---

### 1. OPTICS & RESOLUTION
- **Sensor Native Format:** Large Format 65mm (53.2 x 28.1 mm, 60.2 mm diagonal)
- **Pixel Matrix:** 16384x8640 (141.6 Megapixels, Bayer RGGB)
- **Pixel Pitch:** 3.25 µm (Sensor Nyquist: 153.8 lp/mm)
- **Lens Geometry:** 50.0mm at T3.0 (f/2.8)
- **Diffraction Airy Disk:** 3.76 µm (Cutoff: 649.4 lp/mm)
- **MTF50 Acutance:** 210.0 lp/mm | **Contrast at Nyquist:** 59.8%
- **Optical Resolution Limit Check:** OPTICAL RESOLUTION SATISFIED (Diffraction & Aberrations within tolerance)

### 2. PHOTON RADIOMETRY & DYNAMIC RANGE
- **Exposure:** 60.0 fps, 180.0° shutter angle (8.33 ms)
- **ISO / Gain:** ISO 800.0 (Native Base ISO: 800.0)
- **Incident Photons / Pixel:** 2408.5 photons
- **Signal Charge:** 1975.1 e- (Full-Well: 48000 e-)
- **Signal-to-Noise Ratio (SNR):** 32.8 dB
- **Total Dynamic Range:** 15.62 Stops
- **Usable Dynamic Range (SNR > 0dB):** **14.87 Stops**

### 3. SENSOR READOUT & ADC ARCHITECTURE
- **ADC Resolution:** 16-bit (Column-Parallel SAR ADC (14/16-bit))
- **Parallel Converters:** 16384 Column ADCs @ 0.52 MSPS
- **Effective Number of Bits (ENOB):** 15.4 bits
- **Rolling Shutter Duration:** 5.62 ms
- **Uncompressed Raw Sensor Bandwidth:** **135.90 Gb/s (15.82 GB/s)**

### 4. COMPUTE, ISP & MEMORY PIPELINE
- **ISP Computational Workload:** 3.43 TFLOPS
- **Hardware Pipeline Latency:** 0.09 ms (Hardware ASIC fixed-function)
- **Frame Buffer Size:** 270.0 MB / frame
- **Required DRAM Bandwidth:** 318.9 GB/s (Installed: 820 GB/s, Bus Load: 38.9%)

### 5. CODEC & STORAGE THROUGHPUT
- **Active Codec:** Aureom RAW Cinema (Visually Lossless 3:1) (3.0:1 ratio)
- **Encoded Storage Bitrate:** 5662.3 MB/s (5.27 GB/s)
- **Storage Consumption:** 18.54 TB / hour (444.9 TB / 24hr continuous)
- **Recording Durations:**
  - **1.0 TB Media:** 3.2 minutes (0.05 hours)
  - **2.0 TB Media:** 6.5 minutes (0.11 hours)
  - **4.0 TB Media:** 12.9 minutes (0.22 hours)
  - **8.0 TB Media:** 25.9 minutes (0.43 hours)
  - **16.0 TB Media:** 51.8 minutes (0.86 hours)
  - **32.0 TB Media:** 103.6 minutes (1.73 hours)

### 6. THERMAL & ELECTRICAL SUBSYSTEMS
- **Total Electrical Power Consumption:** **45.7 Watts**
- **Battery Runtime (at 150.0 Wh):** 197.0 minutes (3.28 hours)
- **Ambient Air Temperature:** 25.0°C
- **Sensor Junction Temperature:** 40.7°C
- **ISP Junction Temperature:** 37.3°C
- **Chassis Surface Temperature:** 35.3°C
- **Thermal Digital Twin Status:** **`THERMAL_SAFE`** (Thermal Margin: +64.3°C)

### 7. MANUFACTURING, TOLERANCES & ECONOMICS
- **Chassis Structural Material:** Aerospace Aluminum 6061-T6
- **Total Camera Body Mass:** 2.99 kg
- **Lens Mount:** ARRI LPL Large Format Mount (Flange Depth: 44.000 mm ± 2.0 µm)
- **Assembly Monte Carlo Pass Yield:** 100.0%
- **System MTBF:** 234,525 Operating Hours
- **Bill of Materials (BOM) Cost:** $7,379.00 USD
- **Unit Manufacturing Cost (UMC):** $9,834.15 USD
- **Target Retail MSRP:** **$21,853.66 USD**

### 8. AUTOMATED FACTORY ACCEPTANCE TESTS
| Test ID | Test Specification | Target Spec | Measured | Status | Test Station |
|---|---|---|---|---|---|
| `T01-UNIFORMITY` | Sensor PRNU Uniformity | < 0.50% | 0.38% | **PASS** | Opto-Integrating Sphere Station 1 |
| `T02-DEAD-PIXELS` | Dead Pixel Threshold | < 250 pixels | 42 pixels (All Mapped) | **PASS** | Dark Chamber Station 2 |
| `T03-HOT-PIXELS` | Hot Pixel Leakage (<100 e-/s at 40C) | < 500 pixels | 78 pixels | **PASS** | Dark Chamber Station 2 |
| `T04-DYNAMIC-RANGE` | Usable Cinema Dynamic Range | >= 14.0 Stops | 14.9 Stops | **PASS** | Starlight DR Optical Wedge 3 |
| `T05-READ-NOISE` | Base ISO Floor Read Noise | <= 2.0 e- RMS | 1.80 e- RMS | **PASS** | Low-Noise ADC Spectral Rig 4 |
| `T06-COLOR-ACCURACY` | Colorimetry Mean Delta-E 2000 | < 1.2 dE | 0.85 dE | **PASS** | ColorChecker Semi-Gloss Spectro 5 |
| `T07-WHITE-BALANCE` | CCT Channel Gain Convergence | < 0.5% deviation | 0.18% deviation | **PASS** | Calibrated Xenon / LED Rig 6 |
| `T08-FRAME-RATE` | 16K Native Clock & Jitter | 0 Frame Drops in 30min | 0 Drops (100% Lock) | **PASS** | Bus Analyzer PCIe Gen5 Rig 7 |
| `T09-STORAGE-THROUGHPUT` | Sustained Direct NVMe Write | >= 5.27 GB/s | 14.00 GB/s | **PASS** | High-Speed Direct NVMe Rig 8 |
| `T10-THERMAL-STABILITY` | 60min Full-Load Continuous Capture | Junction < 90°C | Peak 40.7°C | **PASS** | Environmental Temp Chamber 9 |
| `T11-POWER-LIMIT` | Total Peak Electrical Draw | <= 95.0 W | 45.7 W | **PASS** | Precision Digital Power Analyzer 10 |
| `T12-LENS-MOUNT-DEPTH` | Flange Depth Tolerance | +/- 5.0 um | +1.96 um | **PASS** | Laser Interferometer 11 |
| `T13-PHASE-ASSIST` | Dual-Pixel Phase Correlation | Latency < 12ms | 8.2 ms | **PASS** | Optical Phase Chart Rig 12 |
| `T14-STABILISATION` | Sensor-Shift 5-Axis Planarity | Yaw/Pitch/Roll < 0.2 mrad | 0.08 mrad | **PASS** | 6-DOF Hexapod Motion Rig 13 |

---
*Report generated deterministically by AUREOM CAMERA ENGINE Scientific Prototyper.*