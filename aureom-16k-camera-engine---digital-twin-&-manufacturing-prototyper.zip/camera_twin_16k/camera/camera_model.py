"""
Canonical CameraModel: The unified engineering system connecting Optics -> Sensor -> Photons -> Pixel -> Readout -> ADC -> ISP -> Compression -> Storage -> Memory -> Thermal -> Power -> Mechanical -> Manufacturing -> BOM.
"""
from dataclasses import dataclass, field
from typing import Dict, Any, List, Optional
import math

from ..core.types import (
    Resolution, SensorFormat, CFAType, ShutterArchitecture, ADCArchitecture,
    ComputeArchitecture, CodecType, ChassisMaterialType, ThermalCoolingType,
    RES_16K_DCI, RES_8K_DCI, RES_4K_DCI, ThermalStateLevel
)
from ..sensor.sensor_model import SensorModel
from ..optics.optical_system import OpticalSystem
from ..optics.mtf import MTFEngine, LensResolutionReport
from ..lens.lens_model import CinemaLensModel
from ..photon.scene import SyntheticScene, SCENE_PRESETS, SceneType
from ..photon.photon_pipeline import PhotonPipeline, PhotonArrivalResult
from ..pixel.pixel_physics import PixelPhysicsEngine, PixelPhysicsResult
from ..exposure.exposure_engine import ExposureConfiguration
from ..shutter.shutter_model import ShutterModel
from ..readout.readout_engine import ReadoutEngine, ReadoutEngineResult
from ..adc.adc_engine import ADCEngine, ADCEngineResult
from ..isp.isp_engine import ISPEngine, ISPPerformanceResult
from ..hdr.hdr_engine import HDREngine, HDRPerformanceResult
from ..codec.codec_engine import CodecEngine, CodecPerformanceResult
from ..storage.storage_model import StorageSystemModel, StorageCapacityDuration
from ..memory.memory_system import MemorySystemModel, MemorySystemResult
from ..power.power_system import PowerSystemModel, PowerConsumptionBreakdown, BatteryDischargeResult
from ..thermal.thermal_engine import ThermalEngine, ThermalSimulationResult
from ..cooling.cooling_system import CoolingSystemModel
from ..mechanical.chassis_model import MechanicalEngine, MechanicalChassisResult
from ..mount.lens_mount import LensMountSpecification, STANDARD_MOUNTS
from ..tolerances.tolerance_engine import ToleranceEngine, ToleranceStackReport
from ..manufacturing.mfg_engine import ManufacturingEngine
from ..bom.bom_engine import BOMEngine
from ..costing.cost_breakdown import CostEngine, UnitCostEconomics
from ..testing.factory_test import FactoryTestEngine, TestSpecItem
from ..reliability.reliability_model import ReliabilityEngine, ReliabilityReport


@dataclass
class CameraSimulationState:
    """
    Complete state of the camera digital twin resulting from whole-system simulation.
    """
    camera_id: str
    model_name: str

    # Subsystem objects and results
    sensor: SensorModel
    optical_system: OpticalSystem
    exposure: ExposureConfiguration
    shutter: ShutterModel
    mount: LensMountSpecification
    cooling: CoolingSystemModel
    chassis_material: ChassisMaterialType
    ambient_temp_c: float

    # Calculated physical results
    mtf_report: LensResolutionReport
    photon_result: PhotonArrivalResult
    pixel_result: PixelPhysicsResult
    hdr_result: HDRPerformanceResult
    readout_result: ReadoutEngineResult
    adc_result: ADCEngineResult
    isp_result: ISPPerformanceResult
    codec_result: CodecPerformanceResult
    storage: StorageSystemModel
    storage_durations: List[StorageCapacityDuration]
    memory_result: MemorySystemResult
    power_breakdown: PowerConsumptionBreakdown
    battery_result: BatteryDischargeResult
    thermal_result: ThermalSimulationResult
    mechanical_result: MechanicalChassisResult
    tolerances_result: ToleranceStackReport
    manufacturing_summary: dict
    bom_summary: dict
    cost_economics: UnitCostEconomics
    factory_tests: List[TestSpecItem]
    reliability_report: ReliabilityReport

    # High-level summary metrics
    is_spec_satisfied: bool
    system_limiting_factor: str


@dataclass
class CameraModel:
    """
    Canonical Camera Engineering Digital Twin Model.
    Modifying any parameter will cascade throughout all physical, optical, electronic, thermal and manufacturing submodels.
    """
    camera_id: str = "AUR-16K-CINEMA-001"
    model_name: str = "Aureom 16K Cinema Digital Twin"

    # Sensor configuration
    sensor: SensorModel = field(default_factory=SensorModel)

    # Optics and Lens
    optical_system: OpticalSystem = field(default_factory=OpticalSystem)
    lens: CinemaLensModel = field(default_factory=CinemaLensModel)
    mount: LensMountSpecification = field(default_factory=lambda: STANDARD_MOUNTS["LPL"])

    # Exposure & Timing
    exposure: ExposureConfiguration = field(default_factory=ExposureConfiguration)
    shutter: ShutterModel = field(default_factory=ShutterModel)
    bit_depth: int = 16

    # ADC & Processing
    adc_architecture: ADCArchitecture = ADCArchitecture.COLUMN_PARALLEL_SAR
    compute_architecture: ComputeArchitecture = ComputeArchitecture.CUSTOM_ASIC
    is_dual_gain_enabled: bool = True

    # Codec & Storage
    codec_type: CodecType = CodecType.VISUALLY_LOSSLESS_RAW
    custom_compression_ratio: float = 3.0
    storage: StorageSystemModel = field(default_factory=StorageSystemModel)
    memory: MemorySystemModel = field(default_factory=MemorySystemModel)

    # Thermal & Power
    cooling: CoolingSystemModel = field(default_factory=CoolingSystemModel)
    ambient_temp_c: float = 25.0
    battery_capacity_wh: float = 150.0

    # Mechanics & Manufacturing
    chassis_material: ChassisMaterialType = ChassisMaterialType.AEROSPACE_ALUMINUM_6061
    body_width_mm: float = 145.0
    body_height_mm: float = 158.0
    body_depth_mm: float = 210.0
    wall_thickness_mm: float = 3.2

    # Active Scene
    scene: SyntheticScene = field(default_factory=lambda: SCENE_PRESETS[SceneType.CINEMA_STUDIO_KEY])

    def simulate(self) -> CameraSimulationState:
        """
        Executes the canonical physical simulation pipeline and returns the full digital twin state.
        """
        # 1. Optical simulation & MTF
        mtf_report = MTFEngine.calculate_mtf(
            f_stop=self.optical_system.f_stop,
            wavelength_m=self.optical_system.wavelength_m,
            aberration_factor=self.lens.aberration_factor,
            sensor_nyquist_lp_mm=self.sensor.nyquist_frequency_lp_per_mm,
        )

        # 2. Photon radiometry: Scene luminance -> Lens aperture -> Sensor plane
        photon_res = PhotonPipeline.simulate_optical_flux(
            scene_luminance_cd_m2=self.scene.midtone_luminance_cd_m2,
            t_stop=self.optical_system.t_stop,
            lens_transmission=self.optical_system.lens_transmission,
            nd_filter_optical_density=self.exposure.nd_optical_density,
            wavelength_m=self.optical_system.wavelength_m,
        )

        # 3. Pixel charge & noise physics
        dark_curr = self.sensor.dark_current_at_temp(self.ambient_temp_c + 15.0)
        active_read_noise = self.sensor.read_noise_high_gain_e if self.exposure.is_using_high_conversion_gain_circuit else self.sensor.read_noise_low_gain_e

        # Adjust FWC if global shutter overhead is selected
        eff_fwc = self.sensor.full_well_capacity_e * (0.78 if self.shutter.architecture == ShutterArchitecture.ELECTRONIC_GLOBAL else 1.0)

        pixel_res = PixelPhysicsEngine.calculate_pixel_response(
            incident_photon_flux_per_sq_um_per_s=photon_res.photon_flux_per_sq_um_per_s,
            exposure_time_s=self.exposure.exposure_time_s,
            pixel_area_sq_um=self.sensor.pixel_area_sq_um,
            quantum_efficiency=self.sensor.quantum_efficiency_peak,
            read_noise_e=active_read_noise,
            dark_current_e_per_s=dark_curr,
            prnu_percent=self.sensor.prnu_percent,
            full_well_capacity_e=eff_fwc,
            adc_bit_depth=self.bit_depth,
        )

        # 4. HDR dynamic range
        hdr_res = HDREngine.calculate_hdr(
            full_well_e=eff_fwc,
            low_gain_read_noise_e=self.sensor.read_noise_low_gain_e,
            high_gain_read_noise_e=self.sensor.read_noise_high_gain_e,
            is_dual_gain_enabled=self.is_dual_gain_enabled,
        )

        # 5. Readout bandwidth
        readout_res = ReadoutEngine.calculate_readout(
            resolution=self.sensor.resolution,
            frame_rate_fps=self.exposure.frame_rate_fps,
            bit_depth=self.bit_depth,
            shutter_arch=self.shutter.architecture,
        )

        # 6. ADC Engine
        adc_res = ADCEngine.calculate_adc_performance(
            bit_depth=self.bit_depth,
            architecture=self.adc_architecture,
            total_pixels=self.sensor.resolution.total_pixels,
            sensor_width_columns=self.sensor.resolution.width,
            frame_rate_fps=self.exposure.frame_rate_fps,
            saturation_voltage_mv=self.sensor.saturation_voltage_mv,
            conversion_gain_uv_per_e=self.sensor.conversion_gain_uv_per_e,
            full_well_capacity_e=eff_fwc,
        )

        # 7. ISP Performance
        isp_res = ISPEngine.calculate_isp_workload(
            total_pixels=self.sensor.resolution.total_pixels,
            frame_rate_fps=self.exposure.frame_rate_fps,
            bit_depth=self.bit_depth,
        )

        # 8. Codec Engine & Bitrates
        raw_pixels_per_s = float(self.sensor.resolution.total_pixels) * float(self.exposure.frame_rate_fps)
        codec_res = CodecEngine.calculate_codec_metrics(
            raw_bits_per_sec=readout_res.raw_bits_per_second,
            raw_pixels_per_sec=raw_pixels_per_s,
            codec_type=self.codec_type,
            custom_compression_ratio=self.custom_compression_ratio,
        )

        # 9. Storage Durations
        storage_durations = self.storage.calculate_recording_durations(
            encoded_bytes_per_sec=codec_res.encoded_gigabytes_per_second * (1024.0 ** 3)
        )

        # 10. Memory Subsystem
        mem_res = self.memory.calculate_memory_performance(
            total_pixels=self.sensor.resolution.total_pixels,
            frame_rate_fps=self.exposure.frame_rate_fps,
            bit_depth=self.bit_depth,
            isp_dram_bandwidth_gb_s=isp_res.total_memory_bandwidth_gb_per_sec,
            codec_dram_bandwidth_gb_s=codec_res.encoded_gigabytes_per_second * 1.5,
        )

        # 11. Power Distribution & Battery
        # In cinema stacked CMOS architectures, sensor die consumes ~5.5W base + dynamic scaling per MP-fps
        sensor_pwr_w = 5.2 + (0.00065 * self.exposure.frame_rate_fps * (self.sensor.resolution.total_pixels / 1e6))
        storage_pwr_w = 2.5 + (codec_res.encoded_gigabytes_per_second * 0.45)

        power_breakdown, battery_res = PowerSystemModel.calculate_power(
            sensor_watts=sensor_pwr_w,
            adc_watts=adc_res.adc_power_dissipation_watts,
            isp_watts=isp_res.isp_power_watts,
            memory_watts=mem_res.memory_subsystem_power_watts,
            storage_watts=storage_pwr_w,
            cooling_watts=self.cooling.power_consumption_watts,
            battery_capacity_wh=self.battery_capacity_wh,
        )

        # 12. Thermal Simulation & Transient
        thermal_res = ThermalEngine.simulate_thermal(
            ambient_temp_c=self.ambient_temp_c,
            sensor_power_w=sensor_pwr_w,
            adc_power_w=adc_res.adc_power_dissipation_watts,
            isp_power_w=isp_res.isp_power_watts,
            memory_power_w=mem_res.memory_subsystem_power_watts,
            storage_power_w=storage_pwr_w,
            power_reg_loss_w=power_breakdown.power_regulation_losses_watts,
            display_wireless_w=power_breakdown.display_viewfinder_watts + power_breakdown.wireless_remote_watts,
            cooling_type=self.cooling.cooling_type,
            fan_airflow_cfm=self.cooling.airflow_cfm,
        )

        # 13. Mechanical Chassis
        mech_res = MechanicalEngine.calculate_mechanics(
            width_mm=self.body_width_mm,
            height_mm=self.body_height_mm,
            depth_mm=self.body_depth_mm,
            wall_thickness_mm=self.wall_thickness_mm,
            material_type=self.chassis_material,
        )

        # 14. Tolerance Stack-up
        tol_res = ToleranceEngine.run_monte_carlo_tolerances(
            nominal_flange_mm=self.mount.flange_focal_distance_mm,
            num_simulations=1000,
        )

        # 15. Manufacturing, BOM & Economics
        mfg_summary = ManufacturingEngine.calculate_manufacturing_summary()
        bom_summary = BOMEngine.calculate_bom_summary()
        cost_econ = CostEngine.calculate_camera_economics(
            bom_cost_usd=bom_summary["total_bom_cost_usd"],
            direct_labor_usd=mfg_summary["total_direct_labor_cost_usd"],
        )

        # 16. Factory Quality Assurance Tests
        tests = FactoryTestEngine.run_factory_acceptance_suite(
            dynamic_range_stops=hdr_res.usable_dynamic_range_stops,
            read_noise_e=active_read_noise,
            peak_temp_c=thermal_res.sensor_junction_temp_c,
            total_power_w=power_breakdown.total_system_watts,
            storage_write_speed_gb_s=self.storage.sustained_write_bandwidth_gb_s,
            required_storage_gb_s=codec_res.encoded_gigabytes_per_second,
            flange_error_um=tol_res.flange_focal_depth_std_um,
        )

        # 17. Reliability Model
        rel_report = ReliabilityEngine.calculate_reliability(
            sensor_temp_c=thermal_res.sensor_junction_temp_c,
            fan_rpm=self.cooling.current_fan_rpm,
            total_power_w=power_breakdown.total_system_watts,
            camera_mass_kg=mech_res.total_camera_body_mass_kg,
        )

        # Limiting factor detection
        limiting_factors = []
        if mtf_report.is_lens_limiting:
            limiting_factors.append("Optical MTF Limit < Sensor Nyquist")
        if not readout_res.is_frame_rate_achievable:
            limiting_factors.append("Sensor Lane Serializer Bandwidth Saturated")
        if not adc_res.is_throughput_sustainable:
            limiting_factors.append("ADC MSPS Conversion Limit Breached")
        if not mem_res.is_bandwidth_adequate:
            limiting_factors.append("DRAM Bus Bandwidth Saturated (>85%)")
        if not self.storage.is_bandwidth_sufficient(codec_res.encoded_gigabytes_per_second * (1024 ** 3)):
            limiting_factors.append("Storage Sustained Write Limit Exceeded")
        if thermal_res.thermal_state != ThermalStateLevel.THERMAL_SAFE:
            limiting_factors.append(f"Thermal State {thermal_res.thermal_state.value}")

        primary_limiting = ", ".join(limiting_factors) if limiting_factors else "None (Balanced High-Performance Architecture)"
        is_satisfied = len(limiting_factors) == 0

        return CameraSimulationState(
            camera_id=self.camera_id,
            model_name=self.model_name,
            sensor=self.sensor,
            optical_system=self.optical_system,
            exposure=self.exposure,
            shutter=self.shutter,
            mount=self.mount,
            cooling=self.cooling,
            chassis_material=self.chassis_material,
            ambient_temp_c=self.ambient_temp_c,
            mtf_report=mtf_report,
            photon_result=photon_res,
            pixel_result=pixel_res,
            hdr_result=hdr_res,
            readout_result=readout_res,
            adc_result=adc_res,
            isp_result=isp_res,
            codec_result=codec_res,
            storage=self.storage,
            storage_durations=storage_durations,
            memory_result=mem_res,
            power_breakdown=power_breakdown,
            battery_result=battery_res,
            thermal_result=thermal_res,
            mechanical_result=mech_res,
            tolerances_result=tol_res,
            manufacturing_summary=mfg_summary,
            bom_summary=bom_summary,
            cost_economics=cost_econ,
            factory_tests=tests,
            reliability_report=rel_report,
            is_spec_satisfied=is_satisfied,
            system_limiting_factor=primary_limiting,
        )
