"""
Flagship 16K Cinema Camera Factory Configuration (Aureom 16K Cinema Camera).
"""
from .camera_model import CameraModel
from ..core.types import (
    RES_16K_DCI, SensorFormat, CFAType, ShutterArchitecture, ADCArchitecture,
    ComputeArchitecture, CodecType, ChassisMaterialType, ThermalCoolingType
)
from ..sensor.sensor_model import SensorModel
from ..optics.optical_system import OpticalSystem
from ..lens.lens_model import CinemaLensModel
from ..exposure.exposure_engine import ExposureConfiguration
from ..shutter.shutter_model import ShutterModel
from ..mount.lens_mount import STANDARD_MOUNTS


def Aureom16KCinemaCamera(
    resolution=RES_16K_DCI,
    frame_rate_fps: float = 60.0,
    bit_depth: int = 16,
    shutter_arch: ShutterArchitecture = ShutterArchitecture.ELECTRONIC_ROLLING,
    codec_type: CodecType = CodecType.VISUALLY_LOSSLESS_RAW,
    ambient_temp_c: float = 25.0,
) -> CameraModel:
    """
    Constructs the canonical Aureom 16K Large Format Cinema Camera engineering model.
    """
    sensor = SensorModel(
        resolution=resolution,
        pixel_pitch_um=3.25,
        sensor_format=SensorFormat.LARGE_FORMAT,
        cfa_type=CFAType.BAYER_RGGB,
        quantum_efficiency_peak=0.82,
        read_noise_low_gain_e=1.8,
        read_noise_high_gain_e=0.95,
        full_well_capacity_e=48_000.0,
    )

    optics = OpticalSystem(
        focal_length_mm=50.0,
        f_stop=2.8,
        t_stop=3.0,
        focus_distance_m=3.0,
        image_circle_diameter_mm=60.0,
    )

    lens = CinemaLensModel(
        model_name="Aureom Cine Prime 50mm T1.5 LF",
        focal_length_mm=50.0,
        image_circle_mm=60.0,
    )

    exposure = ExposureConfiguration(
        frame_rate_fps=frame_rate_fps,
        shutter_angle_deg=180.0,
        iso=800.0,
        base_iso_low=800.0,
        base_iso_high=3200.0,
    )

    shutter = ShutterModel(
        architecture=shutter_arch,
        line_readout_time_us=0.55,
    )

    return CameraModel(
        camera_id="AUR-16K-CINEMA-FLAGSHIP",
        model_name="Aureom 16K Large Format Cinema Camera",
        sensor=sensor,
        optical_system=optics,
        lens=lens,
        mount=STANDARD_MOUNTS["LPL"],
        exposure=exposure,
        shutter=shutter,
        bit_depth=bit_depth,
        adc_architecture=ADCArchitecture.COLUMN_PARALLEL_SAR,
        compute_architecture=ComputeArchitecture.CUSTOM_ASIC,
        is_dual_gain_enabled=True,
        codec_type=codec_type,
        custom_compression_ratio=3.0,
        ambient_temp_c=ambient_temp_c,
        chassis_material=ChassisMaterialType.AEROSPACE_ALUMINUM_6061,
    )
