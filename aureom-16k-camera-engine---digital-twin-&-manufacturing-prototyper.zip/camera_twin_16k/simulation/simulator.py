"""
Camera Simulator facade for running single simulations, sweep analyses and scenario pipelines.
"""
from typing import Dict, Any, List
from ..camera.camera_model import CameraModel, CameraSimulationState
from .monte_carlo_factory import FactoryMonteCarlo, FactoryBatchSimulationResult


class CameraSimulator:
    """
    High-level simulation orchestrator for the Aureom Camera Engine.
    """

    def __init__(self, camera: CameraModel = None):
        self.camera = camera if camera is not None else CameraModel()

    def run(self) -> CameraSimulationState:
        return self.camera.simulate()

    def run_frame_rate_sweep(self, frame_rates: List[float] = None) -> List[Dict[str, Any]]:
        """
        Sweeps frame rates (e.g. 24, 25, 30, 48, 50, 60, 100, 120, 240 fps)
        and evaluates data rate, power, DRAM bandwidth, and thermal consequences.
        """
        if frame_rates is None:
            frame_rates = [24.0, 30.0, 48.0, 60.0, 100.0, 120.0, 240.0]

        results = []
        original_fps = self.camera.exposure.frame_rate_fps

        for fps in frame_rates:
            self.camera.exposure.frame_rate_fps = fps
            state = self.camera.simulate()
            results.append({
                "fps": fps,
                "raw_gbps": state.readout_result.raw_gigabits_per_second,
                "raw_gb_s": state.readout_result.raw_gigabytes_per_second,
                "encoded_gb_s": state.codec_result.encoded_gigabytes_per_second,
                "dram_bandwidth_gb_s": state.memory_result.required_dram_bandwidth_gb_s,
                "isp_tflops": state.isp_result.total_compute_tflops,
                "total_power_w": state.power_breakdown.total_system_watts,
                "peak_sensor_temp_c": state.thermal_result.sensor_junction_temp_c,
                "thermal_state": state.thermal_result.thermal_state.value,
                "is_achievable": state.readout_result.is_frame_rate_achievable and state.memory_result.is_bandwidth_adequate,
            })

        self.camera.exposure.frame_rate_fps = original_fps
        return results

    def run_factory_monte_carlo(self, num_units: int = 1000) -> FactoryBatchSimulationResult:
        state = self.camera.simulate()
        return FactoryMonteCarlo.simulate_factory_run(
            num_units=num_units,
            baseline_dr_stops=state.hdr_result.usable_dynamic_range_stops,
            baseline_temp_c=state.thermal_result.sensor_junction_temp_c,
            baseline_unit_cost=state.cost_economics.total_unit_manufacturing_cost_usd,
        )
