"""
Factory Monte Carlo: Virtual factory batch simulation across thousands of camera units with silicon, optical and thermal variances.
"""
from dataclasses import dataclass
import random
import math
from typing import Dict, List, Tuple


@dataclass
class FactoryBatchSimulationResult:
    total_virtual_units: int
    yield_percent: float
    scrap_rate_percent: float
    mean_dynamic_range_stops: float
    min_dynamic_range_stops: float
    max_dynamic_range_stops: float
    mean_peak_junction_temp_c: float
    max_peak_junction_temp_c: float
    mean_unit_cost_usd: float
    cost_std_usd: float
    thermal_failures_count: int
    optical_alignment_failures_count: int
    sensor_defect_failures_count: int
    dr_distribution_histogram: List[Dict[str, float]]
    cost_distribution_histogram: List[Dict[str, float]]


class FactoryMonteCarlo:
    """
    Simulates high-volume production line variance and factory yield predictions.
    """

    @staticmethod
    def simulate_factory_run(
        num_units: int = 1000,
        baseline_dr_stops: float = 15.2,
        baseline_temp_c: float = 62.5,
        baseline_unit_cost: float = 8950.0,
        seed: int = 42,
    ) -> FactoryBatchSimulationResult:
        rng = random.Random(seed)

        dr_samples = []
        temp_samples = []
        cost_samples = []

        thermal_fails = 0
        optical_fails = 0
        sensor_fails = 0
        passed_units = 0

        for _ in range(num_units):
            # Sensor silicon read noise and FWC variation (+/- 6% Gaussian)
            sensor_var = rng.gauss(0.0, 0.28)
            unit_dr = max(baseline_dr_stops + sensor_var, 11.0)
            dr_samples.append(unit_dr)

            # Thermal resistance variance (TIM bond-line thickness +/- 12%)
            thermal_var = rng.gauss(0.0, 3.8)
            unit_temp = baseline_temp_c + thermal_var
            temp_samples.append(unit_temp)

            # Unit cost variance (wafer defect density fluctuations)
            cost_var = rng.gauss(0.0, 240.0)
            unit_cost = baseline_unit_cost + cost_var
            cost_samples.append(unit_cost)

            # Mechanical flange alignment tolerance error
            flange_err = abs(rng.gauss(0.0, 2.5))

            # Quality gate validation
            is_pass = True
            if unit_temp > 85.0:
                thermal_fails += 1
                is_pass = False
            if flange_err > 5.0:
                optical_fails += 1
                is_pass = False
            if unit_dr < 13.8:
                sensor_fails += 1
                is_pass = False

            if is_pass:
                passed_units += 1

        yield_pct = (passed_units / num_units) * 100.0
        scrap_pct = 100.0 - yield_pct

        # Build dynamic range histogram (10 bins)
        dr_min, dr_max = min(dr_samples), max(dr_samples)
        bin_width = (dr_max - dr_min) / 10.0 if dr_max > dr_min else 0.5
        dr_bins = []
        for b in range(10):
            b_low = dr_min + b * bin_width
            b_high = b_low + bin_width
            count = sum(1 for x in dr_samples if b_low <= x < b_high or (b == 9 and x >= b_high))
            dr_bins.append({"bin_label": f"{b_low:.1f}-{b_high:.1f} stops", "count": count})

        # Cost histogram
        c_min, c_max = min(cost_samples), max(cost_samples)
        c_bin_width = (c_max - c_min) / 10.0 if c_max > c_min else 100.0
        cost_bins = []
        for b in range(10):
            b_low = c_min + b * c_bin_width
            b_high = b_low + c_bin_width
            count = sum(1 for x in cost_samples if b_low <= x < b_high or (b == 9 and x >= b_high))
            cost_bins.append({"bin_label": f"${b_low:.0f}-${b_high:.0f}", "count": count})

        mean_cost = sum(cost_samples) / len(cost_samples)
        cost_std = math.sqrt(sum((x - mean_cost) ** 2 for x in cost_samples) / len(cost_samples))

        return FactoryBatchSimulationResult(
            total_virtual_units=num_units,
            yield_percent=yield_pct,
            scrap_rate_percent=scrap_pct,
            mean_dynamic_range_stops=sum(dr_samples) / len(dr_samples),
            min_dynamic_range_stops=dr_min,
            max_dynamic_range_stops=dr_max,
            mean_peak_junction_temp_c=sum(temp_samples) / len(temp_samples),
            max_peak_junction_temp_c=max(temp_samples),
            mean_unit_cost_usd=mean_cost,
            cost_std_usd=cost_std,
            thermal_failures_count=thermal_fails,
            optical_alignment_failures_count=optical_fails,
            sensor_defect_failures_count=sensor_fails,
            dr_distribution_histogram=dr_bins,
            cost_distribution_histogram=cost_bins,
        )
