"""
Cinema colour science engine: ACES AP0/AP1 matrices, Rec.2020 / DCI-P3, log curves (AureomLog3), and 3D LUT simulation.
"""
from dataclasses import dataclass
import math
from typing import List, Tuple


@dataclass
class ColourSpaceMatrix:
    name: str
    matrix_3x3: List[List[float]]


# Standard Cinema Gamut Matrices (XYZ to RGB)
ACES_AP0_TO_XYZ = ColourSpaceMatrix("ACES AP0 to XYZ", [
    [0.9525523959, 0.0000000000, 0.0000936786],
    [0.3439664498, 0.7281660966, -0.0721325464],
    [0.0000000000, 0.0000000000, 1.0088251844]
])

REC2020_TO_XYZ = ColourSpaceMatrix("Rec.2020 to XYZ", [
    [0.636958, 0.144617, 0.168881],
    [0.262700, 0.677998, 0.059302],
    [0.000000, 0.028073, 1.060985]
])


class ColourScienceEngine:
    """
    Simulates modular wide-gamut transformations and logarithmic transfer functions.
    """

    @staticmethod
    def linear_to_aureom_log(linear_val: float) -> float:
        """
        Original logarithmic transfer function for 16-stop dynamic range mapping:
        y = c * log10(a * x + b) + d
        """
        if linear_val <= 0.005:
            return max(linear_val * 4.5, 0.0)
        a = 15.0
        b = 1.0
        c = 0.28
        d = 0.38
        return (c * math.log10(a * linear_val + b)) + d

    @staticmethod
    def aureom_log_to_linear(log_val: float) -> float:
        """Inverse log transfer."""
        if log_val <= 0.0225:
            return log_val / 4.5
        c = 0.28
        d = 0.38
        a = 15.0
        b = 1.0
        return (10.0 ** ((log_val - d) / c) - b) / a
