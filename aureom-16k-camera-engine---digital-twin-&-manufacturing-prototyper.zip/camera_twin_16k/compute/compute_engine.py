"""
Compute architecture model: ASIC vs GPU vs FPGA vs DSP/NPU compute efficiency, TFLOPS, memory bandwidth, and power.
"""
from dataclasses import dataclass
from ..core.types import ComputeArchitecture


@dataclass
class ArchitectureComparisonResult:
    architecture: ComputeArchitecture
    efficiency_tflops_per_watt: float
    total_compute_power_watts: float
    die_area_sq_mm_estimate: float
    development_nre_cost_usd: float
    unit_silicon_cost_usd: float


class ComputeEngine:
    """
    Compares hardware execution engines for the 16K computational workload.
    """

    @staticmethod
    def evaluate_architectures(workload_tflops: float) -> list[ArchitectureComparisonResult]:
        architectures = [
            (ComputeArchitecture.CUSTOM_ASIC, 2.6, 65.0, 15_000_000.0, 320.0),
            (ComputeArchitecture.GPU_HBM, 0.75, 140.0, 1_500_000.0, 650.0),
            (ComputeArchitecture.FPGA_ACCELERATOR, 0.45, 220.0, 400_000.0, 1200.0),
            (ComputeArchitecture.HETEROGENEOUS_NPU, 1.85, 85.0, 8_000_000.0, 420.0),
        ]

        results = []
        for arch, eff, area, nre, unit_cost in architectures:
            power = (workload_tflops / eff) + 5.0
            results.append(ArchitectureComparisonResult(
                architecture=arch,
                efficiency_tflops_per_watt=eff,
                total_compute_power_watts=power,
                die_area_sq_mm_estimate=area,
                development_nre_cost_usd=nre,
                unit_silicon_cost_usd=unit_cost,
            ))
        return results
