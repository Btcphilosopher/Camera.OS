"""
Modulation Transfer Function (MTF) modeling and spatial frequency limit analysis.
"""
from dataclasses import dataclass
import math
from typing import Dict, List, Tuple


@dataclass
class MTFPoint:
    frequency_lp_mm: float
    mtf_center: float
    mtf_edge: float


@dataclass
class LensResolutionReport:
    mtf10_lp_mm: float  # Resolution limit lp/mm (10% contrast)
    mtf20_lp_mm: float  # High-detail limit lp/mm
    mtf50_lp_mm: float  # Perceived sharpness / acutance lp/mm (50% contrast)
    sensor_nyquist_lp_mm: float
    is_lens_limiting: bool
    contrast_at_nyquist_percent: float
    mtf_curve: List[MTFPoint]


class MTFEngine:
    """
    Computes realistic cinema prime MTF curves using combined diffraction and aberration degradation models.
    """

    @staticmethod
    def calculate_mtf(
        f_stop: float,
        wavelength_m: float,
        aberration_factor: float = 0.85,
        sensor_nyquist_lp_mm: float = 153.8,  # Default for 3.25um pitch
    ) -> LensResolutionReport:
        # Theoretical diffraction cutoff frequency in lp/mm
        cutoff_lp_mm = (1.0 / (wavelength_m * f_stop)) / 1000.0

        curve: List[MTFPoint] = []
        mtf10_lp_mm = 0.0
        mtf20_lp_mm = 0.0
        mtf50_lp_mm = 0.0
        contrast_at_nyquist = 0.0

        frequencies = [float(f) for f in range(0, int(min(cutoff_lp_mm, 400.0)) + 1, 5)]
        if not frequencies:
            frequencies = [0.0, 50.0, 100.0, 150.0, 200.0]

        for nu in frequencies:
            if nu == 0.0:
                center_mtf = 1.0
                edge_mtf = 0.95
            elif nu >= cutoff_lp_mm:
                center_mtf = 0.0
                edge_mtf = 0.0
            else:
                # Normalized spatial frequency
                s = nu / cutoff_lp_mm
                # Ideal diffraction MTF for circular pupil: (2/pi) * (arccos(s) - s * sqrt(1 - s^2))
                diffraction_mtf = (2.0 / math.pi) * (math.acos(s) - s * math.sqrt(max(1.0 - s ** 2, 0.0)))
                # Apply optical aberration attenuation (higher degradation at higher frequencies and field edges)
                aberration_attenuation = math.exp(-1.5 * (s ** 1.3) * (1.0 - aberration_factor))
                center_mtf = max(diffraction_mtf * aberration_factor * aberration_attenuation, 0.0)
                edge_mtf = max(center_mtf * (1.0 - 0.25 * (s ** 0.8)), 0.0)

            curve.append(MTFPoint(frequency_lp_mm=nu, mtf_center=center_mtf, mtf_edge=edge_mtf))

            if center_mtf >= 0.50:
                mtf50_lp_mm = nu
            if center_mtf >= 0.20:
                mtf20_lp_mm = nu
            if center_mtf >= 0.10:
                mtf10_lp_mm = nu

            if abs(nu - sensor_nyquist_lp_mm) < 6.0:
                contrast_at_nyquist = center_mtf * 100.0

        is_lens_limiting = mtf10_lp_mm < sensor_nyquist_lp_mm

        return LensResolutionReport(
            mtf10_lp_mm=mtf10_lp_mm,
            mtf20_lp_mm=mtf20_lp_mm,
            mtf50_lp_mm=mtf50_lp_mm,
            sensor_nyquist_lp_mm=sensor_nyquist_lp_mm,
            is_lens_limiting=is_lens_limiting,
            contrast_at_nyquist_percent=contrast_at_nyquist,
            mtf_curve=curve,
        )
