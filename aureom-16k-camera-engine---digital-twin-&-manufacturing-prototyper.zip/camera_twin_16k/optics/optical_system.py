"""
Optical simulator: Field of view, Entrance Pupil, Depth of Field, Airy Disk, Diffraction, and Resolving Power.
"""
from dataclasses import dataclass
import math
from typing import Dict, List, Tuple
from ..core.constants import REF_WAVELENGTH_M


@dataclass
class OpticalSystem:
    """
    Geometrical and physical optics model for cinema prime/zoom systems.
    """
    focal_length_mm: float = 50.0  # mm
    f_stop: float = 2.8  # f-number
    t_stop: float = 3.0  # Photometric T-stop
    lens_transmission: float = 0.90  # 90% transmission efficiency
    wavelength_m: float = REF_WAVELENGTH_M  # 550 nm (green peak)
    focus_distance_m: float = 2.5  # Subject distance in meters
    circle_of_confusion_mm: float = 0.020  # standard cinema CoC for large format
    lens_element_count: int = 15
    image_circle_diameter_mm: float = 60.0  # Large format image circle
    vignetting_corner_falloff_percent: float = 12.0  # Cos4 / mechanical shading falloff
    chromatic_aberration_lateral_um: float = 1.8  # lateral color fringe in um
    distortion_barrel_pincushion_percent: float = -0.35  # slight barrel distortion

    @property
    def entrance_pupil_diameter_mm(self) -> float:
        """Entrance pupil diameter D = f / N."""
        return self.focal_length_mm / max(self.f_stop, 0.5)

    def calculate_fov(self, sensor_width_mm: float, sensor_height_mm: float) -> Tuple[float, float, float]:
        """Calculates horizontal, vertical, and diagonal Field of View in degrees."""
        diag_mm = math.sqrt(sensor_width_mm ** 2 + sensor_height_mm ** 2)
        hfov = 2.0 * math.degrees(math.atan(sensor_width_mm / (2.0 * self.focal_length_mm)))
        vfov = 2.0 * math.degrees(math.atan(sensor_height_mm / (2.0 * self.focal_length_mm)))
        dfov = 2.0 * math.degrees(math.atan(diag_mm / (2.0 * self.focal_length_mm)))
        return hfov, vfov, dfov

    @property
    def airy_disk_diameter_um(self) -> float:
        """
        Diffraction-limited Airy disk diameter: d = 2.44 * lambda * N
        """
        d_meters = 2.44 * self.wavelength_m * self.f_stop
        return d_meters * 1_000_000.0  # return in micrometers

    @property
    def diffraction_cutoff_frequency_lp_mm(self) -> float:
        """
        Diffraction cutoff spatial frequency fc = 1 / (lambda * N) in lp/mm.
        """
        fc_m = 1.0 / (self.wavelength_m * self.f_stop)
        return fc_m / 1000.0

    def calculate_depth_of_field(self) -> Tuple[float, float, float, float]:
        """
        Calculates hyperfocal distance, near limit, far limit, and total DoF (in meters).
        """
        f_mm = self.focal_length_mm
        N = self.f_stop
        c_mm = self.circle_of_confusion_mm
        s_mm = self.focus_distance_m * 1000.0

        # Hyperfocal distance H = (f^2) / (N * c) + f
        H_mm = (f_mm ** 2) / (N * c_mm) + f_mm
        H_m = H_mm / 1000.0

        if s_mm >= H_mm:
            near_m = (H_mm * s_mm) / (H_mm + (s_mm - f_mm)) / 1000.0
            far_m = float('inf')
            dof_m = float('inf')
        else:
            near_mm = (H_mm * s_mm) / (H_mm + (s_mm - f_mm))
            far_mm = (H_mm * s_mm) / (H_mm - (s_mm - f_mm))
            near_m = near_mm / 1000.0
            far_m = far_mm / 1000.0
            dof_m = far_m - near_m

        return H_m, near_m, far_m, dof_m

    def is_diffraction_limited_for_pixel_pitch(self, pixel_pitch_um: float) -> bool:
        """
        Returns True if the Airy disk diameter exceeds the Nyquist sampling pitch (2 * pixel_pitch).
        """
        return self.airy_disk_diameter_um > (2.0 * pixel_pitch_um)
