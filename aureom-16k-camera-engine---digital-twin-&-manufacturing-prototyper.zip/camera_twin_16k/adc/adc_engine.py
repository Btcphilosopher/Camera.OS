"""
ADC Engine: Column-parallel quantisation, LSB electron voltage resolution, sampling speed, parallel power dissipation, and ENOB.
"""
from dataclasses import dataclass
import math
from ..core.types import ADCArchitecture


@dataclass
class ADCEngineResult:
    bit_depth: int
    architecture: ADCArchitecture
    num_parallel_converters: int
    conversion_rate_msps_per_adc: float
    total_aggregate_gigasamples_per_sec: float
    lsb_voltage_uv: float
    lsb_electrons: float
    quantisation_noise_rms_uv: float
    effective_number_of_bits_enob: float
    adc_power_dissipation_watts: float
    is_throughput_sustainable: bool


class ADCEngine:
    """
    Models column-parallel analog-to-digital converters array on stacked CMOS logic wafer.
    """

    @staticmethod
    def calculate_adc_performance(
        bit_depth: int,
        architecture: ADCArchitecture,
        total_pixels: int,
        sensor_width_columns: int,
        frame_rate_fps: float,
        saturation_voltage_mv: float = 850.0,
        conversion_gain_uv_per_e: float = 45.0,
        full_well_capacity_e: float = 48_000.0,
    ) -> ADCEngineResult:
        # Number of ADC units: 1 per column (or 2 per column for dual-gain top/bottom)
        if architecture == ADCArchitecture.DUAL_GAIN_ADC:
            num_adcs = sensor_width_columns * 2
        else:
            num_adcs = sensor_width_columns

        # Aggregate sample rate
        total_samples_per_sec = float(total_pixels) * float(frame_rate_fps)
        total_gsps = total_samples_per_sec / 1_000_000_000.0

        # Per-ADC conversion rate in MSPS (Mega-samples per second)
        conversion_rate_msps = (total_samples_per_sec / float(num_adcs)) / 1_000_000.0

        # LSB calculation: V_ref / 2^N
        v_ref_uv = saturation_voltage_mv * 1000.0
        num_quant_levels = 2 ** bit_depth
        lsb_uv = v_ref_uv / float(num_quant_levels)
        lsb_e = full_well_capacity_e / float(num_quant_levels)

        # Quantisation noise: q / sqrt(12)
        q_noise_uv = lsb_uv / math.sqrt(12.0)

        # Effective Number of Bits (ENOB) accounting for thermal noise and integral non-linearity (INL/DNL)
        # Typically 0.4 to 0.8 bit degradation from ideal
        enob = max(bit_depth - 0.55, 8.0)

        # Energy per conversion step (approx 8 pJ per sample for cinema-grade SAR)
        energy_per_conversion_pj = 8.5 * (2 ** max(bit_depth - 12, 0) * 0.45)
        adc_power_w = (total_samples_per_sec * energy_per_conversion_pj * 1e-12) + (num_adcs * 0.0001)

        # High-speed cinema ADCs can sustain up to ~15 MSPS per column in stacked 16nm CMOS
        is_sustainable = conversion_rate_msps <= 25.0

        return ADCEngineResult(
            bit_depth=bit_depth,
            architecture=architecture,
            num_parallel_converters=num_adcs,
            conversion_rate_msps_per_adc=conversion_rate_msps,
            total_aggregate_gigasamples_per_sec=total_gsps,
            lsb_voltage_uv=lsb_uv,
            lsb_electrons=lsb_e,
            quantisation_noise_rms_uv=q_noise_uv,
            effective_number_of_bits_enob=enob,
            adc_power_dissipation_watts=adc_power_w,
            is_throughput_sustainable=is_sustainable,
        )
