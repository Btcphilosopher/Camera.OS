"""
Reliability modeling: Component MTBF, Failure-in-Time (FIT), thermal cycling wear-out, and mechanical shock / vibration resistance.
"""
from dataclasses import dataclass
import math
from typing import Dict, List


@dataclass
class ReliabilityReport:
    system_mtbf_hours: float
    annual_failure_rate_percent: float
    fit_rate_total: float  # Failures in 10^9 hours
    thermal_cycling_lifetime_cycles: int
    vibration_g_rms_rating: float
    shock_g_peak_rating: float
    critical_subsystem_risks: List[Dict[str, str]]


class ReliabilityEngine:
    @staticmethod
    def calculate_reliability(
        sensor_temp_c: float = 42.0,
        fan_rpm: float = 3200.0,
        total_power_w: float = 68.0,
        camera_mass_kg: float = 2.45,
    ) -> ReliabilityReport:
        # Arrhenius thermal acceleration factor for electronics life: AF = exp((Ea/k) * (1/T_ref - 1/T_op))
        # Ea approx 0.7 eV
        t_ref_k = 293.15 + 25.0
        t_op_k = 293.15 + sensor_temp_c
        af = math.exp((0.7 / 8.617e-5) * ((1.0 / t_ref_k) - (1.0 / t_op_k)))

        # Subsystem FIT rates (Failures in 1 billion operating hours)
        base_sensor_fit = 450.0 * af
        base_isp_fit = 380.0 * af
        base_dram_fit = 220.0 * af
        base_fan_fit = 320.0 * (fan_rpm / 3000.0) ** 1.5
        base_connectors_fit = 180.0
        base_pmic_fit = 250.0

        total_fit = base_sensor_fit + base_isp_fit + base_dram_fit + base_fan_fit + base_connectors_fit + base_pmic_fit
        mtbf_hours = 1_000_000_000.0 / total_fit
        annual_failure_rate = (8760.0 / mtbf_hours) * 100.0

        # Mechanical shock load: F = m * a (e.g. 50G cinema drop resistance)
        shock_g = 50.0
        shock_force_n = camera_mass_kg * 9.81 * shock_g

        risks = [
            {"subsystem": "Stacked 16K Sensor Die Interconnects", "risk": "LOW - BSI micro-bump reliability validated past 10,000 thermal cycles"},
            {"subsystem": "MagLev Active Cooling Fan", "risk": "MEDIUM - Wearout item with 60,000 hr continuous L10 bearing life rating"},
            {"subsystem": "PCIe Gen5 High-Speed Direct NVMe Socket", "risk": "LOW - Gold-plated 10,000 cycle insertion rating"},
        ]

        return ReliabilityReport(
            system_mtbf_hours=mtbf_hours,
            annual_failure_rate_percent=annual_failure_rate,
            fit_rate_total=total_fit,
            thermal_cycling_lifetime_cycles=12500,
            vibration_g_rms_rating=4.5,
            shock_g_peak_rating=shock_g,
            critical_subsystem_risks=risks,
        )
