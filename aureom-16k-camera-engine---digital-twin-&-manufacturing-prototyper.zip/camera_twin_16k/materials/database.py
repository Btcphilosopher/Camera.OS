"""
Engineering materials database for camera body structures, mounts, heatsinks and shields.
"""
from dataclasses import dataclass
from typing import Dict
from ..core.types import ChassisMaterialType


@dataclass
class MaterialProperties:
    name: str
    density_g_per_cm3: float
    thermal_conductivity_w_per_m_k: float
    yield_strength_mpa: float
    cost_per_kg_usd: float
    machinability_factor: float  # Relative to aluminum 6061 = 1.0


MATERIALS_DATABASE: Dict[ChassisMaterialType, MaterialProperties] = {
    ChassisMaterialType.AEROSPACE_ALUMINUM_6061: MaterialProperties(
        name="Aerospace Aluminum 6061-T6",
        density_g_per_cm3=2.70,
        thermal_conductivity_w_per_m_k=167.0,
        yield_strength_mpa=276.0,
        cost_per_kg_usd=8.50,
        machinability_factor=1.0,
    ),
    ChassisMaterialType.AEROSPACE_ALUMINUM_7075: MaterialProperties(
        name="Aerospace Aluminum 7075-T6",
        density_g_per_cm3=2.81,
        thermal_conductivity_w_per_m_k=130.0,
        yield_strength_mpa=503.0,
        cost_per_kg_usd=14.20,
        machinability_factor=0.8,
    ),
    ChassisMaterialType.MAGNESIUM_ALLOY_AZ91D: MaterialProperties(
        name="Magnesium Alloy AZ91D Die-Cast",
        density_g_per_cm3=1.81,
        thermal_conductivity_w_per_m_k=72.0,
        yield_strength_mpa=160.0,
        cost_per_kg_usd=18.00,
        machinability_factor=1.4,
    ),
    ChassisMaterialType.TITANIUM_GRADE_5: MaterialProperties(
        name="Titanium Grade 5 (Ti-6Al-4V)",
        density_g_per_cm3=4.43,
        thermal_conductivity_w_per_m_k=6.7,
        yield_strength_mpa=880.0,
        cost_per_kg_usd=65.00,
        machinability_factor=0.35,
    ),
    ChassisMaterialType.CARBON_FIBER_PEEK: MaterialProperties(
        name="Toray Carbon-Fiber / PEEK Composite",
        density_g_per_cm3=1.45,
        thermal_conductivity_w_per_m_k=4.5,
        yield_strength_mpa=650.0,
        cost_per_kg_usd=110.00,
        machinability_factor=0.5,
    ),
}
