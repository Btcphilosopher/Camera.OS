"""
Total Unit Manufacturing Cost (UMC), NRE amortization, direct labor, testing, calibration, warranty reserve and MSRP economics.
"""
from dataclasses import dataclass


@dataclass
class UnitCostEconomics:
    component_bom_cost_usd: float
    assembly_labor_cost_usd: float
    testing_and_burnin_cost_usd: float
    optical_calibration_cost_usd: float
    packaging_and_accessories_usd: float
    logistics_and_freight_usd: float
    warranty_reserve_usd: float  # 3-year cinema warranty reserve (3.5%)
    factory_overhead_and_tooling_usd: float
    total_unit_manufacturing_cost_usd: float
    target_gross_margin_percent: float
    suggested_msrp_usd: float
    pilot_prototype_cost_usd: float  # 10x higher due to non-amortized NRE


class CostEngine:
    @staticmethod
    def calculate_camera_economics(
        bom_cost_usd: float = 7131.00,
        direct_labor_usd: float = 680.00,
        annual_production_volume: int = 1500,
        target_margin_percent: float = 55.0,
    ) -> UnitCostEconomics:
        testing_cost = 240.00
        calibration_cost = 180.00
        packaging_cost = 160.00
        logistics_cost = 125.00
        overhead = 450.00

        subtotal = (
            bom_cost_usd +
            direct_labor_usd +
            testing_cost +
            calibration_cost +
            packaging_cost +
            logistics_cost +
            overhead
        )

        warranty_reserve = subtotal * 0.045
        umc = subtotal + warranty_reserve

        # MSRP = UMC / (1 - Margin)
        margin_frac = target_margin_percent / 100.0
        msrp = umc / max(1.0 - margin_frac, 0.1)

        # Prototype unit cost (with single wafer run / soft tooling)
        prototype_cost = (bom_cost_usd * 3.8) + 12_500.0

        return UnitCostEconomics(
            component_bom_cost_usd=bom_cost_usd,
            assembly_labor_cost_usd=direct_labor_usd,
            testing_and_burnin_cost_usd=testing_cost,
            optical_calibration_cost_usd=calibration_cost,
            packaging_and_accessories_usd=packaging_cost,
            logistics_and_freight_usd=logistics_cost,
            warranty_reserve_usd=warranty_reserve,
            factory_overhead_and_tooling_usd=overhead,
            total_unit_manufacturing_cost_usd=umc,
            target_gross_margin_percent=target_margin_percent,
            suggested_msrp_usd=msrp,
            pilot_prototype_cost_usd=prototype_cost,
        )
