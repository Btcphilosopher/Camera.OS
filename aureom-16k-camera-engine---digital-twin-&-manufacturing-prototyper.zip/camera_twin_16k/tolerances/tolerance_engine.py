"""
Mechanical tolerance stack-up and Monte Carlo assembly variance simulation.
"""
from dataclasses import dataclass
import random
import math
from typing import Dict, List, Tuple


@dataclass
class ToleranceStackReport:
    num_iterations: int
    flange_focal_depth_mean_mm: float
    flange_focal_depth_std_um: float
    sensor_tilt_mean_arcmin: float
    sensor_tilt_max_arcmin: float
    optical_axis_decenter_mean_um: float
    assembly_pass_yield_percent: float
    depth_distribution_samples: List[float]


class ToleranceEngine:
    """
    Monte Carlo statistical tolerance simulator for 6-axis precision sensor alignment.
    """

    @staticmethod
    def run_monte_carlo_tolerances(
        nominal_flange_mm: float = 44.000,
        flange_machining_tol_um: float = 4.0,
        sensor_shim_tol_um: float = 2.5,
        sensor_die_attach_tol_um: float = 3.0,
        chassis_thermal_expansion_tol_um: float = 2.0,
        max_allowable_depth_error_um: float = 8.0,
        max_allowable_tilt_arcmin: float = 2.5,
        num_simulations: int = 2500,
        seed: int = 42,
    ) -> ToleranceStackReport:
        rng = random.Random(seed)

        depth_errors_um: List[float] = []
        tilts_arcmin: List[float] = []
        decenters_um: List[float] = []
        passes = 0

        for _ in range(num_simulations):
            # Normal distribution 3-sigma sample for each mechanical interface
            flange_err = rng.gauss(0.0, flange_machining_tol_um / 3.0)
            shim_err = rng.gauss(0.0, sensor_shim_tol_um / 3.0)
            die_attach_err = rng.gauss(0.0, sensor_die_attach_tol_um / 3.0)
            thermal_err = rng.gauss(0.0, chassis_thermal_expansion_tol_um / 3.0)

            total_depth_err_um = flange_err + shim_err + die_attach_err + thermal_err
            depth_errors_um.append(total_depth_err_um)

            # Tilt in arcminutes: atan(delta_z / sensor_width)
            tilt_z1 = rng.gauss(0.0, 1.8)
            tilt_z2 = rng.gauss(0.0, 1.8)
            delta_tilt_um = abs(tilt_z1 - tilt_z2)
            tilt_arcmin = (math.atan(delta_tilt_um / (53.0 * 1000.0)) * (180.0 / math.pi)) * 60.0
            tilts_arcmin.append(tilt_arcmin)

            # X/Y Decenter in um
            dx = rng.gauss(0.0, 3.5)
            dy = rng.gauss(0.0, 3.5)
            decenter_mag = math.sqrt(dx ** 2 + dy ** 2)
            decenters_um.append(decenter_mag)

            # Verification against cinema depth and tilt tolerances
            if abs(total_depth_err_um) <= max_allowable_depth_error_um and tilt_arcmin <= max_allowable_tilt_arcmin:
                passes += 1

        pass_yield = (passes / num_simulations) * 100.0
        mean_depth_err = sum(depth_errors_um) / len(depth_errors_um)
        std_depth = math.sqrt(sum((x - mean_depth_err) ** 2 for x in depth_errors_um) / len(depth_errors_um))

        return ToleranceStackReport(
            num_iterations=num_simulations,
            flange_focal_depth_mean_mm=nominal_flange_mm + (mean_depth_err / 1000.0),
            flange_focal_depth_std_um=std_depth,
            sensor_tilt_mean_arcmin=sum(tilts_arcmin) / len(tilts_arcmin),
            sensor_tilt_max_arcmin=max(tilts_arcmin),
            optical_axis_decenter_mean_um=sum(decenters_um) / len(decenters_um),
            assembly_pass_yield_percent=pass_yield,
            depth_distribution_samples=depth_errors_um[:100],  # 100 preview samples
        )
