"""
High-level programmatic API for external consumers (Kotlin UI, REST clients, automation scripts).
"""
from typing import Dict, Any, List
from ..camera.camera_model import CameraModel
from ..camera.flagship import Aureom16KCinemaCamera
from ..export.report_generator import ReportGenerator
from ..simulation.simulator import CameraSimulator
from ..simulation.monte_carlo_factory import FactoryMonteCarlo
from ..scenarios.scenario_engine import ScenarioEngine, SCENARIO_PRESETS
from ..core.types import (
    Resolution, SensorFormat, CFAType, ShutterArchitecture, ADCArchitecture,
    ComputeArchitecture, CodecType, ChassisMaterialType, ThermalCoolingType
)


class AureomEngineAPI:
    """
    Exposes clean stateless and stateful endpoints for digital twin analysis.
    """

    @staticmethod
    def simulate_camera_config(config_dict: Dict[str, Any]) -> Dict[str, Any]:
        width = int(config_dict.get("resolution_width", 16384))
        height = int(config_dict.get("resolution_height", 8640))
        fps = float(config_dict.get("fps", 60.0))
        bit_depth = int(config_dict.get("bit_depth", 16))
        pixel_pitch = float(config_dict.get("pixel_pitch_um", 3.25))
        f_stop = float(config_dict.get("f_stop", 2.8))
        focal_length = float(config_dict.get("focal_length_mm", 50.0))
        iso = float(config_dict.get("iso", 800.0))
        ambient_c = float(config_dict.get("ambient_temp_c", 25.0))
        compression_ratio = float(config_dict.get("compression_ratio", 3.0))
        shutter_str = config_dict.get("shutter_arch", "rolling")

        shutter_arch = ShutterArchitecture.ELECTRONIC_GLOBAL if "global" in shutter_str.lower() else ShutterArchitecture.ELECTRONIC_ROLLING

        cam = Aureom16KCinemaCamera(
            resolution=Resolution(width, height, f"{width}x{height}"),
            frame_rate_fps=fps,
            bit_depth=bit_depth,
            shutter_arch=shutter_arch,
            ambient_temp_c=ambient_c,
        )
        cam.sensor.pixel_pitch_um = pixel_pitch
        cam.optical_system.f_stop = f_stop
        cam.optical_system.t_stop = f_stop * 1.05
        cam.optical_system.focal_length_mm = focal_length
        cam.exposure.iso = iso
        cam.custom_compression_ratio = compression_ratio

        state = cam.simulate()
        return ReportGenerator.to_dict(state)

    @staticmethod
    def run_monte_carlo(num_units: int = 1000, baseline_dr: float = 15.2, baseline_temp: float = 62.5) -> Dict[str, Any]:
        res = FactoryMonteCarlo.simulate_factory_run(num_units=num_units, baseline_dr_stops=baseline_dr, baseline_temp_c=baseline_temp)
        return {
            "total_virtual_units": res.total_virtual_units,
            "yield_percent": res.yield_percent,
            "scrap_rate_percent": res.scrap_rate_percent,
            "mean_dynamic_range_stops": res.mean_dynamic_range_stops,
            "min_dynamic_range_stops": res.min_dynamic_range_stops,
            "max_dynamic_range_stops": res.max_dynamic_range_stops,
            "mean_peak_junction_temp_c": res.mean_peak_junction_temp_c,
            "max_peak_junction_temp_c": res.max_peak_junction_temp_c,
            "mean_unit_cost_usd": res.mean_unit_cost_usd,
            "cost_std_usd": res.cost_std_usd,
            "thermal_failures_count": res.thermal_failures_count,
            "optical_alignment_failures_count": res.optical_alignment_failures_count,
            "sensor_defect_failures_count": res.sensor_defect_failures_count,
            "dr_distribution_histogram": res.dr_distribution_histogram,
            "cost_distribution_histogram": res.cost_distribution_histogram,
        }

    @staticmethod
    def list_presets() -> List[Dict[str, Any]]:
        return [
            {"id": k, "name": k, "description": v["description"], "fps": v["fps"], "bit_depth": v["bit_depth"]}
            for k, v in SCENARIO_PRESETS.items()
        ]
