"""
Cinema Codec Engine: Compression ratio, bitrate (Gbps, MB/s), encoder complexity, latency, power, and storage requirements.
"""
from dataclasses import dataclass
from ..core.types import CodecType


@dataclass
class CodecPerformanceResult:
    codec_type: CodecType
    compression_ratio: float
    encoded_bits_per_second: float
    encoded_megabytes_per_second: float
    encoded_gigabytes_per_second: float
    encoder_complexity_gops_per_pixel: float
    encoder_power_watts: float
    storage_terabytes_per_hour: float
    storage_terabytes_per_day_continuous: float


class CodecEngine:
    """
    Simulates intra-frame and RAW wavelet compression pipelines.
    """

    @staticmethod
    def calculate_codec_metrics(
        raw_bits_per_sec: float,
        raw_pixels_per_sec: float,
        codec_type: CodecType,
        custom_compression_ratio: float = 3.0,
    ) -> CodecPerformanceResult:
        if codec_type == CodecType.UNCOMPRESSED_RAW:
            ratio = 1.0
            complexity_gops = 0.5
            enc_power = 1.8
        elif codec_type == CodecType.VISUALLY_LOSSLESS_RAW:
            ratio = custom_compression_ratio if custom_compression_ratio >= 1.5 else 3.0
            complexity_gops = 14.0
            enc_power = 6.5
        elif codec_type == CodecType.MATHEMATICALLY_LOSSLESS_RAW:
            ratio = 1.8
            complexity_gops = 22.0
            enc_power = 8.2
        elif codec_type == CodecType.PRORES_4444_XQ:
            ratio = 4.5
            complexity_gops = 18.0
            enc_power = 7.0
        elif codec_type == CodecType.HEVC_PRO_INTRA:
            ratio = 12.0
            complexity_gops = 65.0
            enc_power = 11.5
        else:
            ratio = max(custom_compression_ratio, 1.0)
            complexity_gops = 15.0
            enc_power = 6.0

        encoded_bits_per_sec = raw_bits_per_sec / ratio
        encoded_mb_per_sec = (encoded_bits_per_sec / 8.0) / 1_000_000.0
        encoded_gb_per_sec = (encoded_bits_per_sec / 8.0) / (1024.0 ** 3)

        # Storage consumption per hour and per day
        tb_per_hour = (encoded_bits_per_sec / 8.0 * 3600.0) / (1024.0 ** 4)
        tb_per_day = tb_per_hour * 24.0

        return CodecPerformanceResult(
            codec_type=codec_type,
            compression_ratio=ratio,
            encoded_bits_per_second=encoded_bits_per_sec,
            encoded_megabytes_per_second=encoded_mb_per_sec,
            encoded_gigabytes_per_second=encoded_gb_per_sec,
            encoder_complexity_gops_per_pixel=complexity_gops,
            encoder_power_watts=enc_power,
            storage_terabytes_per_hour=tb_per_hour,
            storage_terabytes_per_day_continuous=tb_per_day,
        )
