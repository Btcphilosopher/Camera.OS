"""
Storage package init.
"""
from .storage_model import StorageSystemModel, StorageCapacityDuration

__all__ = ["StorageSystemModel", "StorageCapacityDuration"]
