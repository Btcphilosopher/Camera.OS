"""
Storage recording media calculations (CFexpress Type B/4.0, NVMe PCIe Gen5, U.2 Cinema SSDs, RAID) and recording duration tables.
"""
from dataclasses import dataclass
from typing import Dict, List


@dataclass
class StorageCapacityDuration:
    capacity_tb: float
    capacity_bytes: float
    recording_minutes: float
    recording_hours: float


@dataclass
class StorageSystemModel:
    media_type: str = "Dual NVMe PCIe Gen5 Cinema SSD Cartridge (Direct-to-Mag)"
    sustained_write_bandwidth_gb_s: float = 14.0  # GB/s sustained write limit
    storage_capacities_tb: List[float] = None

    def __post_init__(self):
        if self.storage_capacities_tb is None:
            self.storage_capacities_tb = [1.0, 2.0, 4.0, 8.0, 16.0, 32.0]

    def calculate_recording_durations(self, encoded_bytes_per_sec: float) -> List[StorageCapacityDuration]:
        results: List[StorageCapacityDuration] = []
        eff_bytes_per_sec = max(encoded_bytes_per_sec, 1.0)
        for cap_tb in self.storage_capacities_tb:
            cap_bytes = cap_tb * (1024.0 ** 4)
            seconds = cap_bytes / eff_bytes_per_sec
            minutes = seconds / 60.0
            hours = minutes / 60.0
            results.append(StorageCapacityDuration(
                capacity_tb=cap_tb,
                capacity_bytes=cap_bytes,
                recording_minutes=minutes,
                recording_hours=hours,
            ))
        return results

    def is_bandwidth_sufficient(self, encoded_bytes_per_sec: float) -> bool:
        encoded_gb_s = encoded_bytes_per_sec / (1024.0 ** 3)
        return encoded_gb_s <= self.sustained_write_bandwidth_gb_s
