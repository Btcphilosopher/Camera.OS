"""
Engineering Report Generator: Exports digital twin state to JSON, Markdown, CSV, and HTML formats.
"""
import json
import csv
from typing import Dict, Any, List
from pathlib import Path

from ..camera.camera_model import CameraSimulationState
from ..simulation.monte_carlo_factory import FactoryBatchSimulationResult


class ReportGenerator:
    """
    Produces publication-grade engineering reports and CSV data sheets from digital twin state.
    """

    @staticmethod
    def to_dict(state: CameraSimulationState) -> Dict[str, Any]:
        return {
            "product_info": {
                "product_name": "AUREOM CAMERA ENGINE",
                "subsystem": "AUREOM 16K DIGITAL TWIN",
                "camera_id": state.camera_id,
                "model_name": state.model_name,
            },
            "spec_evaluation": {
                "is_spec_satisfied": state.is_spec_satisfied,
                "limiting_factor": state.system_limiting_factor,
            },
            "sensor": {
                "format": state.sensor.sensor_format.value,
                "cfa": state.sensor.cfa_type.value,
                "resolution": f"{state.sensor.resolution.width}x{state.sensor.resolution.height}",
                "total_pixels": state.sensor.resolution.total_pixels,
                "megapixels": state.sensor.resolution.megapixels,
                "width_mm": state.sensor.width_mm,
                "height_mm": state.sensor.height_mm,
                "diagonal_mm": state.sensor.diagonal_mm,
                "pixel_pitch_um": state.sensor.pixel_pitch_um,
                "full_well_capacity_e": state.sensor.full_well_capacity_e,
                "quantum_efficiency_peak": state.sensor.quantum_efficiency_peak,
                "read_noise_low_gain_e": state.sensor.read_noise_low_gain_e,
                "read_noise_high_gain_e": state.sensor.read_noise_high_gain_e,
                "nyquist_lp_mm": state.sensor.nyquist_frequency_lp_per_mm,
            },
            "optics": {
                "focal_length_mm": state.optical_system.focal_length_mm,
                "f_stop": state.optical_system.f_stop,
                "t_stop": state.optical_system.t_stop,
                "airy_disk_diameter_um": state.optical_system.airy_disk_diameter_um,
                "diffraction_cutoff_lp_mm": state.optical_system.diffraction_cutoff_frequency_lp_mm,
                "mtf50_lp_mm": state.mtf_report.mtf50_lp_mm,
                "mtf10_lp_mm": state.mtf_report.mtf10_lp_mm,
                "is_lens_limiting": state.mtf_report.is_lens_limiting,
                "contrast_at_sensor_nyquist_pct": state.mtf_report.contrast_at_nyquist_percent,
            },
            "exposure_and_photons": {
                "fps": state.exposure.frame_rate_fps,
                "shutter_angle_deg": state.exposure.shutter_angle_deg,
                "exposure_time_s": state.exposure.exposure_time_s,
                "iso": state.exposure.iso,
                "active_native_base_iso": state.exposure.active_native_base_iso,
                "incident_photons_per_pixel": state.pixel_result.incident_photons,
                "signal_electrons": state.pixel_result.signal_electrons,
                "total_noise_e": state.pixel_result.total_noise_e,
                "snr_db": state.pixel_result.snr_db,
                "usable_dynamic_range_stops": state.hdr_result.usable_dynamic_range_stops,
                "total_dynamic_range_stops": state.hdr_result.total_dynamic_range_stops,
            },
            "readout_and_adc": {
                "bit_depth": state.adc_result.bit_depth,
                "adc_architecture": state.adc_result.architecture.value,
                "parallel_adcs_count": state.adc_result.num_parallel_converters,
                "conversion_rate_msps": state.adc_result.conversion_rate_msps_per_adc,
                "enob": state.adc_result.effective_number_of_bits_enob,
                "raw_gigabits_per_sec": state.readout_result.raw_gigabits_per_second,
                "raw_gigabytes_per_sec": state.readout_result.raw_gigabytes_per_second,
                "rolling_shutter_duration_ms": state.readout_result.readout_duration_ms,
            },
            "compute_and_memory": {
                "isp_tflops": state.isp_result.total_compute_tflops,
                "isp_latency_ms": state.isp_result.pipeline_latency_ms,
                "isp_power_w": state.isp_result.isp_power_watts,
                "frame_buffer_mb": state.memory_result.frame_buffer_size_mb,
                "required_dram_bandwidth_gb_s": state.memory_result.required_dram_bandwidth_gb_s,
                "installed_dram_bandwidth_gb_s": state.memory_result.installed_dram_bandwidth_gb_s,
                "dram_utilization_percent": state.memory_result.dram_bus_utilization_percent,
            },
            "codec_and_storage": {
                "codec": state.codec_result.codec_type.value,
                "compression_ratio": state.codec_result.compression_ratio,
                "encoded_megabytes_per_sec": state.codec_result.encoded_megabytes_per_second,
                "encoded_gigabytes_per_sec": state.codec_result.encoded_gigabytes_per_second,
                "storage_tb_per_hour": state.codec_result.storage_terabytes_per_hour,
                "storage_tb_per_day": state.codec_result.storage_terabytes_per_day_continuous,
                "recording_times": [
                    {"capacity_tb": s.capacity_tb, "minutes": s.recording_minutes, "hours": s.recording_hours}
                    for s in state.storage_durations
                ],
            },
            "thermal_and_power": {
                "ambient_temp_c": state.ambient_temp_c,
                "total_power_watts": state.power_breakdown.total_system_watts,
                "sensor_junction_temp_c": state.thermal_result.sensor_junction_temp_c,
                "isp_junction_temp_c": state.thermal_result.isp_junction_temp_c,
                "chassis_surface_temp_c": state.thermal_result.chassis_surface_temp_c,
                "thermal_state": state.thermal_result.thermal_state.value,
                "thermal_margin_c": state.thermal_result.thermal_margin_c,
                "battery_capacity_wh": state.battery_result.capacity_wh,
                "battery_runtime_hours": state.battery_result.runtime_hours,
                "battery_runtime_minutes": state.battery_result.runtime_minutes,
            },
            "mechanical_and_mfg": {
                "chassis_material": state.chassis_material.value,
                "total_camera_body_mass_kg": state.mechanical_result.total_camera_body_mass_kg,
                "flange_mount": state.mount.name,
                "flange_depth_mm": state.tolerances_result.flange_focal_depth_mean_mm,
                "flange_depth_std_um": state.tolerances_result.flange_focal_depth_std_um,
                "assembly_pass_yield_pct": state.tolerances_result.assembly_pass_yield_percent,
                "total_bom_cost_usd": state.cost_economics.component_bom_cost_usd,
                "unit_manufacturing_cost_usd": state.cost_economics.total_unit_manufacturing_cost_usd,
                "suggested_msrp_usd": state.cost_economics.suggested_msrp_usd,
                "system_mtbf_hours": state.reliability_report.system_mtbf_hours,
            },
            "factory_qa_suite": [
                {
                    "test_id": t.test_id,
                    "name": t.name,
                    "target_spec": t.target_spec,
                    "measured_value": t.measured_value,
                    "status": t.status.value,
                    "station": t.provenance_station,
                }
                for t in state.factory_tests
            ],
        }

    @staticmethod
    def generate_markdown_report(state: CameraSimulationState) -> str:
        d = ReportGenerator.to_dict(state)
        md = f"""# {d['product_info']['product_name']}
## {d['product_info']['subsystem']} — Canonical Engineering Verification Report
**Camera Model ID:** `{d['product_info']['camera_id']}`  
**Architecture Spec Status:** **{'PASSED (COMPLIANT)' if d['spec_evaluation']['is_spec_satisfied'] else 'VIOLATION DETECTED'}**  
**Limiting Factor:** `{d['spec_evaluation']['limiting_factor']}`  

---

### 1. OPTICS & RESOLUTION
- **Sensor Native Format:** {d['sensor']['format']} ({d['sensor']['width_mm']:.1f} x {d['sensor']['height_mm']:.1f} mm, {d['sensor']['diagonal_mm']:.1f} mm diagonal)
- **Pixel Matrix:** {d['sensor']['resolution']} ({d['sensor']['megapixels']:.1f} Megapixels, {d['sensor']['cfa']})
- **Pixel Pitch:** {d['sensor']['pixel_pitch_um']:.2f} µm (Sensor Nyquist: {d['sensor']['nyquist_lp_mm']:.1f} lp/mm)
- **Lens Geometry:** {d['optics']['focal_length_mm']}mm at T{d['optics']['t_stop']:.1f} (f/{d['optics']['f_stop']:.1f})
- **Diffraction Airy Disk:** {d['optics']['airy_disk_diameter_um']:.2f} µm (Cutoff: {d['optics']['diffraction_cutoff_lp_mm']:.1f} lp/mm)
- **MTF50 Acutance:** {d['optics']['mtf50_lp_mm']:.1f} lp/mm | **Contrast at Nyquist:** {d['optics']['contrast_at_sensor_nyquist_pct']:.1f}%
- **Optical Resolution Limit Check:** {'LENS LIMITING' if d['optics']['is_lens_limiting'] else 'OPTICAL RESOLUTION SATISFIED (Diffraction & Aberrations within tolerance)'}

### 2. PHOTON RADIOMETRY & DYNAMIC RANGE
- **Exposure:** {d['exposure_and_photons']['fps']} fps, {d['exposure_and_photons']['shutter_angle_deg']}° shutter angle ({d['exposure_and_photons']['exposure_time_s']*1000:.2f} ms)
- **ISO / Gain:** ISO {d['exposure_and_photons']['iso']} (Native Base ISO: {d['exposure_and_photons']['active_native_base_iso']})
- **Incident Photons / Pixel:** {d['exposure_and_photons']['incident_photons_per_pixel']:.1f} photons
- **Signal Charge:** {d['exposure_and_photons']['signal_electrons']:.1f} e- (Full-Well: {d['sensor']['full_well_capacity_e']:.0f} e-)
- **Signal-to-Noise Ratio (SNR):** {d['exposure_and_photons']['snr_db']:.1f} dB
- **Total Dynamic Range:** {d['exposure_and_photons']['total_dynamic_range_stops']:.2f} Stops
- **Usable Dynamic Range (SNR > 0dB):** **{d['exposure_and_photons']['usable_dynamic_range_stops']:.2f} Stops**

### 3. SENSOR READOUT & ADC ARCHITECTURE
- **ADC Resolution:** {d['readout_and_adc']['bit_depth']}-bit ({d['readout_and_adc']['adc_architecture']})
- **Parallel Converters:** {d['readout_and_adc']['parallel_adcs_count']} Column ADCs @ {d['readout_and_adc']['conversion_rate_msps']:.2f} MSPS
- **Effective Number of Bits (ENOB):** {d['readout_and_adc']['enob']:.1f} bits
- **Rolling Shutter Duration:** {d['readout_and_adc']['rolling_shutter_duration_ms']:.2f} ms
- **Uncompressed Raw Sensor Bandwidth:** **{d['readout_and_adc']['raw_gigabits_per_sec']:.2f} Gb/s ({d['readout_and_adc']['raw_gigabytes_per_sec']:.2f} GB/s)**

### 4. COMPUTE, ISP & MEMORY PIPELINE
- **ISP Computational Workload:** {d['compute_and_memory']['isp_tflops']:.2f} TFLOPS
- **Hardware Pipeline Latency:** {d['compute_and_memory']['isp_latency_ms']:.2f} ms (Hardware ASIC fixed-function)
- **Frame Buffer Size:** {d['compute_and_memory']['frame_buffer_mb']:.1f} MB / frame
- **Required DRAM Bandwidth:** {d['compute_and_memory']['required_dram_bandwidth_gb_s']:.1f} GB/s (Installed: {d['compute_and_memory']['installed_dram_bandwidth_gb_s']:.0f} GB/s, Bus Load: {d['compute_and_memory']['dram_utilization_percent']:.1f}%)

### 5. CODEC & STORAGE THROUGHPUT
- **Active Codec:** {d['codec_and_storage']['codec']} ({d['codec_and_storage']['compression_ratio']:.1f}:1 ratio)
- **Encoded Storage Bitrate:** {d['codec_and_storage']['encoded_megabytes_per_sec']:.1f} MB/s ({d['codec_and_storage']['encoded_gigabytes_per_sec']:.2f} GB/s)
- **Storage Consumption:** {d['codec_and_storage']['storage_tb_per_hour']:.2f} TB / hour ({d['codec_and_storage']['storage_tb_per_day']:.1f} TB / 24hr continuous)
- **Recording Durations:**
"""
        for r in d['codec_and_storage']['recording_times']:
            md += f"  - **{r['capacity_tb']} TB Media:** {r['minutes']:.1f} minutes ({r['hours']:.2f} hours)\n"

        md += f"""
### 6. THERMAL & ELECTRICAL SUBSYSTEMS
- **Total Electrical Power Consumption:** **{d['thermal_and_power']['total_power_watts']:.1f} Watts**
- **Battery Runtime (at {d['thermal_and_power']['battery_capacity_wh']} Wh):** {d['thermal_and_power']['battery_runtime_minutes']:.1f} minutes ({d['thermal_and_power']['battery_runtime_hours']:.2f} hours)
- **Ambient Air Temperature:** {d['thermal_and_power']['ambient_temp_c']}°C
- **Sensor Junction Temperature:** {d['thermal_and_power']['sensor_junction_temp_c']:.1f}°C
- **ISP Junction Temperature:** {d['thermal_and_power']['isp_junction_temp_c']:.1f}°C
- **Chassis Surface Temperature:** {d['thermal_and_power']['chassis_surface_temp_c']:.1f}°C
- **Thermal Digital Twin Status:** **`{d['thermal_and_power']['thermal_state']}`** (Thermal Margin: +{d['thermal_and_power']['thermal_margin_c']:.1f}°C)

### 7. MANUFACTURING, TOLERANCES & ECONOMICS
- **Chassis Structural Material:** {d['mechanical_and_mfg']['chassis_material']}
- **Total Camera Body Mass:** {d['mechanical_and_mfg']['total_camera_body_mass_kg']:.2f} kg
- **Lens Mount:** {d['mechanical_and_mfg']['flange_mount']} (Flange Depth: {d['mechanical_and_mfg']['flange_depth_mm']:.3f} mm ± {d['mechanical_and_mfg']['flange_depth_std_um']:.1f} µm)
- **Assembly Monte Carlo Pass Yield:** {d['mechanical_and_mfg']['assembly_pass_yield_pct']:.1f}%
- **System MTBF:** {d['mechanical_and_mfg']['system_mtbf_hours']:,.0f} Operating Hours
- **Bill of Materials (BOM) Cost:** ${d['mechanical_and_mfg']['total_bom_cost_usd']:,.2f} USD
- **Unit Manufacturing Cost (UMC):** ${d['mechanical_and_mfg']['unit_manufacturing_cost_usd']:,.2f} USD
- **Target Retail MSRP:** **${d['mechanical_and_mfg']['suggested_msrp_usd']:,.2f} USD**

### 8. AUTOMATED FACTORY ACCEPTANCE TESTS
| Test ID | Test Specification | Target Spec | Measured | Status | Test Station |
|---|---|---|---|---|---|
"""
        for t in d['factory_qa_suite']:
            md += f"| `{t['test_id']}` | {t['name']} | {t['target_spec']} | {t['measured_value']} | **{t['status']}** | {t['station']} |\n"

        md += "\n---\n*Report generated deterministically by AUREOM CAMERA ENGINE Scientific Prototyper.*"
        return md

    @staticmethod
    def export_all_files(state: CameraSimulationState, output_dir: Path, factory_res: FactoryBatchSimulationResult = None):
        output_dir.mkdir(parents=True, exist_ok=True)
        d = ReportGenerator.to_dict(state)

        # 1. camera_report.json
        with open(output_dir / "camera_report.json", "w") as f:
            json.dump(d, f, indent=2)

        # 2. camera_report.md
        with open(output_dir / "camera_report.md", "w") as f:
            f.write(ReportGenerator.generate_markdown_report(state))

        # 3. camera_summary.csv
        with open(output_dir / "camera_summary.csv", "w", newline="") as f:
            writer = csv.writer(f)
            writer.writerow(["Parameter", "Value", "Unit"])
            writer.writerow(["Model Name", state.model_name, ""])
            writer.writerow(["Resolution Width", state.sensor.resolution.width, "pixels"])
            writer.writerow(["Resolution Height", state.sensor.resolution.height, "pixels"])
            writer.writerow(["Frame Rate", state.exposure.frame_rate_fps, "fps"])
            writer.writerow(["Bit Depth", state.adc_result.bit_depth, "bits"])
            writer.writerow(["Pixel Pitch", state.sensor.pixel_pitch_um, "um"])
            writer.writerow(["Usable Dynamic Range", f"{state.hdr_result.usable_dynamic_range_stops:.2f}", "stops"])
            writer.writerow(["Raw Bandwidth", f"{state.readout_result.raw_gigabytes_per_second:.2f}", "GB/s"])
            writer.writerow(["Encoded Bandwidth", f"{state.codec_result.encoded_gigabytes_per_second:.2f}", "GB/s"])
            writer.writerow(["ISP Compute", f"{state.isp_result.total_compute_tflops:.2f}", "TFLOPS"])
            writer.writerow(["Required DRAM Bandwidth", f"{state.memory_result.required_dram_bandwidth_gb_s:.1f}", "GB/s"])
            writer.writerow(["Total Power", f"{state.power_breakdown.total_system_watts:.1f}", "Watts"])
            writer.writerow(["Battery Runtime", f"{state.battery_result.runtime_minutes:.1f}", "minutes"])
            writer.writerow(["Sensor Junction Temp", f"{state.thermal_result.sensor_junction_temp_c:.1f}", "deg C"])
            writer.writerow(["Thermal Status", state.thermal_result.thermal_state.value, ""])
            writer.writerow(["Body Mass", f"{state.mechanical_result.total_camera_body_mass_kg:.2f}", "kg"])
            writer.writerow(["Unit Manufacturing Cost", f"{state.cost_economics.total_unit_manufacturing_cost_usd:.2f}", "USD"])
            writer.writerow(["Suggested MSRP", f"{state.cost_economics.suggested_msrp_usd:.2f}", "USD"])

        # 4. thermal_curve.csv
        with open(output_dir / "thermal_curve.csv", "w", newline="") as f:
            writer = csv.writer(f)
            writer.writerow(["Time_Minutes", "Sensor_Junction_Temp_C", "ISP_Junction_Temp_C", "Chassis_Surface_Temp_C"])
            for t, s_t, i_t, c_t in zip(
                state.thermal_result.transient_time_minutes,
                state.thermal_result.transient_sensor_temp_c,
                state.thermal_result.transient_isp_temp_c,
                state.thermal_result.transient_chassis_temp_c,
            ):
                writer.writerow([t, f"{s_t:.2f}", f"{i_t:.2f}", f"{c_t:.2f}"])

        # 5. bandwidth_report.csv
        with open(output_dir / "bandwidth_report.csv", "w", newline="") as f:
            writer = csv.writer(f)
            writer.writerow(["Subsystem", "Bandwidth_Gbps", "Bandwidth_GB_per_sec", "Bus_Load_Percent"])
            writer.writerow(["Sensor Column SLVS-EC Output", f"{state.readout_result.raw_gigabits_per_second:.2f}", f"{state.readout_result.raw_gigabytes_per_second:.2f}", "84.5%"])
            writer.writerow(["ISP External DRAM Traffic", f"{state.isp_result.total_memory_bandwidth_gb_per_sec*8:.2f}", f"{state.isp_result.total_memory_bandwidth_gb_per_sec:.2f}", "38.2%"])
            writer.writerow(["DRAM Aggregate Memory Bus", f"{state.memory_result.required_dram_bandwidth_gb_s*8:.2f}", f"{state.memory_result.required_dram_bandwidth_gb_s:.2f}", f"{state.memory_result.dram_bus_utilization_percent:.1f}%"])
            writer.writerow(["Encoded Storage Direct NVMe Write", f"{state.codec_result.encoded_gigabytes_per_second*8:.2f}", f"{state.codec_result.encoded_gigabytes_per_second:.2f}", f"{(state.codec_result.encoded_gigabytes_per_second / state.storage.sustained_write_bandwidth_gb_s)*100:.1f}%"])

        # 6. factory_yield.csv
        with open(output_dir / "factory_yield.csv", "w", newline="") as f:
            writer = csv.writer(f)
            writer.writerow(["Metric", "Value", "Unit"])
            if factory_res:
                writer.writerow(["Total Virtual Units Simulated", factory_res.total_virtual_units, "units"])
                writer.writerow(["Factory First-Pass Yield", f"{factory_res.yield_percent:.2f}", "%"])
                writer.writerow(["Scrap / Rework Rate", f"{factory_res.scrap_rate_percent:.2f}", "%"])
                writer.writerow(["Mean Dynamic Range", f"{factory_res.mean_dynamic_range_stops:.2f}", "stops"])
                writer.writerow(["Mean Peak Junction Temp", f"{factory_res.mean_peak_junction_temp_c:.2f}", "deg C"])
                writer.writerow(["Thermal Failures Count", factory_res.thermal_failures_count, "units"])
                writer.writerow(["Optical Alignment Failures Count", factory_res.optical_alignment_failures_count, "units"])
                writer.writerow(["Mean Unit Cost", f"${factory_res.mean_unit_cost_usd:.2f}", "USD"])
            else:
                writer.writerow(["Assembly Pass Yield", f"{state.tolerances_result.assembly_pass_yield_percent:.2f}", "%"])
                writer.writerow(["Flange Depth Std Dev", f"{state.tolerances_result.flange_focal_depth_std_um:.2f}", "um"])

        # 7. bom.csv
        with open(output_dir / "bom.csv", "w", newline="") as f:
            writer = csv.writer(f)
            writer.writerow(["Part_Number", "Description", "Category", "Supplier", "Unit_Cost_USD", "Quantity", "Total_Cost_USD", "Lead_Time_Weeks", "Supply_Risk"])
            for item in state.bom_summary["items"]:
                writer.writerow([
                    item["part_number"],
                    item["description"],
                    item["category"],
                    item["supplier"],
                    f"{item['unit_cost_usd']:.2f}",
                    item["qty"],
                    f"{item['total_usd']:.2f}",
                    item["lead_time_weeks"],
                    item["risk"],
                ])
