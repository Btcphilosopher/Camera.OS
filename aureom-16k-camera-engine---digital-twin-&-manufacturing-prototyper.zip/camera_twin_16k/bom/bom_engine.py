"""
Bill of Materials (BOM) catalog and component supply chain risk model.
"""
from dataclasses import dataclass
from typing import List


@dataclass
class BOMItem:
    part_number: str
    description: str
    category: str
    supplier: str
    unit_cost_usd: float
    quantity: int
    lead_time_weeks: int
    minimum_order_qty: int
    supply_risk: str  # 'LOW', 'MEDIUM', 'HIGH (Single-Source)'

    @property
    def total_cost_usd(self) -> float:
        return self.unit_cost_usd * self.quantity


CANONICAL_BOM: List[BOMItem] = [
    BOMItem("AUR-SNS-16K-LF01", "16K Large Format Stacked BSI Dual-Gain CMOS Sensor", "Sensor", "Aureom Semi Foundry", 4200.00, 1, 26, 100, "HIGH (Single-Source Custom Wafer)"),
    BOMItem("AUR-ISP-CINEMA-V4", "Aureom CineEngine-IV 16K Hardware ISP ASIC 4nm", "Processor", "TSMC / ASE Packaging", 680.00, 1, 20, 500, "MEDIUM (Dedicated Mask)"),
    BOMItem("MEM-HBM3-32GB-820G", "32GB HBM3 2.5D Stacked DRAM Die Interposer", "Memory", "SK Hynix / Micron", 340.00, 1, 14, 250, "MEDIUM"),
    BOMItem("NVME-PCIE5-8TB-MAG", "8TB Direct-to-Mag High-Endurance NVMe PCIe Gen5 SSD", "Storage", "Kioxia / Solidigm", 620.00, 1, 8, 100, "LOW"),
    BOMItem("PWR-PMIC-CINEMA-45A", "Multiphase Digital PMIC & GaN Power Regulators", "Power", "Texas Instruments", 48.00, 2, 6, 1000, "LOW"),
    BOMItem("PCB-16L-HDI-ANYLAYER", "16-Layer High-Density Interconnect Main PCB", "Electronics", "Unimicron / TTM", 125.00, 1, 8, 500, "LOW"),
    BOMItem("MNT-LPL-SS316L", "Precision Stainless Steel 316L LPL Lens Mount Ring", "Mechanical", "Aureom Precision CNC", 185.00, 1, 6, 200, "LOW"),
    BOMItem("CHS-AL6061-MONOCOQUE", "Aerospace 6061-T6 5-Axis CNC Unibody Monocoque Chassis", "Mechanical", "Plexus / Foxconn Precision", 240.00, 1, 10, 250, "LOW"),
    BOMItem("COOL-VC-MAGLEV-BLW", "Sealed Copper Vapor Chamber + Dual MagLev Blowers", "Cooling", "Delta Electronics", 95.00, 1, 6, 500, "LOW"),
    BOMItem("DSP-OLED-4K-EVF", "0.71-inch Micro-OLED Electronic Viewfinder 4K", "Display", "Sony Semiconductor", 280.00, 1, 12, 200, "MEDIUM"),
    BOMItem("CONN-12GSDI-LEMO-IP67", "Quad 12G-SDI BNC + LEMO 2B Power/Timecode I/O Harness", "Connectors", "LEMO / Hirose", 110.00, 1, 6, 500, "LOW"),
    BOMItem("BATT-BMOUNT-28V-PLATE", "Integrated 28.8V High-Voltage B-Mount Power Plate", "Power", "Bebob / Anton Bauer", 75.00, 1, 6, 250, "LOW"),
    BOMItem("OPT-OLPF-IRCUT-GLASS", "Sapphire-Coated Optical Low-Pass Filter & IR-Cut Window", "Optics", "Schott Optical Glass", 145.00, 1, 8, 200, "LOW"),
    BOMItem("FST-TI-HARDWARE-KIT", "Grade 5 Titanium Torx Fasteners & Viton IP54 O-Rings", "Hardware", "Bossard", 28.00, 1, 4, 2000, "LOW"),
    BOMItem("PKG-PELICAN-PRO-CASE", "Custom Pelican Storm Hard Case with Laser Foam Insert", "Packaging", "Pelican Products", 160.00, 1, 4, 100, "LOW"),
]


class BOMEngine:
    @staticmethod
    def calculate_bom_summary() -> dict:
        total_parts_cost = sum(item.total_cost_usd for item in CANONICAL_BOM)
        max_lead_time_weeks = max(item.lead_time_weeks for item in CANONICAL_BOM)
        high_risk_items = [item for item in CANONICAL_BOM if "HIGH" in item.supply_risk]

        category_breakdown = {}
        for item in CANONICAL_BOM:
            category_breakdown[item.category] = category_breakdown.get(item.category, 0.0) + item.total_cost_usd

        return {
            "total_bom_cost_usd": total_parts_cost,
            "critical_path_lead_time_weeks": max_lead_time_weeks,
            "total_unique_parts_count": len(CANONICAL_BOM),
            "high_risk_components_count": len(high_risk_items),
            "category_costs": category_breakdown,
            "items": [
                {
                    "part_number": i.part_number,
                    "description": i.description,
                    "category": i.category,
                    "supplier": i.supplier,
                    "unit_cost_usd": i.unit_cost_usd,
                    "qty": i.quantity,
                    "total_usd": i.total_cost_usd,
                    "lead_time_weeks": i.lead_time_weeks,
                    "risk": i.supply_risk,
                }
                for i in CANONICAL_BOM
            ],
        }
