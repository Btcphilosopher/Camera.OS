"""
Thermal digital twin: Lumped thermal resistance networks, heat dissipation per subsystem, and transient continuous recording simulation.
"""
from dataclasses import dataclass, field
import math
from typing import Dict, List, Tuple
from ..core.types import ThermalStateLevel, ThermalCoolingType


@dataclass
class ComponentThermalNode:
    name: str
    power_watts: float
    r_theta_jc_c_per_w: float  # Junction-to-case thermal resistance
    r_theta_cs_c_per_w: float  # Case-to-sink (TIM) thermal resistance
    heat_capacity_j_per_c: float  # Thermal mass (C = m * c_p)
    max_junction_temp_c: float = 105.0


@dataclass
class ThermalSimulationResult:
    ambient_temp_c: float
    total_power_watts: float
    sensor_junction_temp_c: float
    isp_junction_temp_c: float
    dram_junction_temp_c: float
    chassis_surface_temp_c: float
    thermal_state: ThermalStateLevel
    thermal_margin_c: float
    transient_time_minutes: List[float]
    transient_sensor_temp_c: List[float]
    transient_isp_temp_c: List[float]
    transient_chassis_temp_c: List[float]


class ThermalEngine:
    """
    Thermal digital twin for conduction, vapor chamber spread and active convection.
    """

    @staticmethod
    def simulate_thermal(
        ambient_temp_c: float,
        sensor_power_w: float,
        adc_power_w: float,
        isp_power_w: float,
        memory_power_w: float,
        storage_power_w: float,
        power_reg_loss_w: float,
        display_wireless_w: float,
        cooling_type: ThermalCoolingType = ThermalCoolingType.DUAL_BLOWER_VAPOR_CHAMBER,
        fan_airflow_cfm: float = 8.5,
    ) -> ThermalSimulationResult:
        # Heatsink & chassis thermal resistance depending on cooling architecture
        if cooling_type == ThermalCoolingType.PASSIVE_CONDUCTION:
            r_sink_ambient = 1.25  # High resistance without airflow
        elif cooling_type == ThermalCoolingType.ACTIVE_QUIET_FAN:
            r_sink_ambient = 0.45 / (max(fan_airflow_cfm, 1.0) / 5.0)
        elif cooling_type == ThermalCoolingType.DUAL_BLOWER_VAPOR_CHAMBER:
            r_sink_ambient = 0.28 / (max(fan_airflow_cfm, 1.0) / 6.0)
        elif cooling_type == ThermalCoolingType.LIQUID_MICRO_CHANNEL:
            r_sink_ambient = 0.16
        else:
            r_sink_ambient = 0.35

        total_system_power_w = (
            sensor_power_w +
            adc_power_w +
            isp_power_w +
            memory_power_w +
            storage_power_w +
            power_reg_loss_w +
            display_wireless_w
        )

        # Steady-state chassis & heatsink temperature
        t_chassis_c = ambient_temp_c + (total_system_power_w * r_sink_ambient)

        # Component junction temperatures: T_j = T_sink + P_comp * (R_jc + R_cs)
        r_sensor_jc = 0.42  # Sensor die to copper heat spreader
        t_sensor_j = t_chassis_c + (sensor_power_w + adc_power_w) * r_sensor_jc

        r_isp_jc = 0.35  # ISP ASIC flip-chip to vapor chamber
        t_isp_j = t_chassis_c + (isp_power_w * r_isp_jc)

        r_dram_jc = 0.50
        t_dram_j = t_chassis_c + (memory_power_w * r_dram_jc)

        # Peak component temp
        peak_temp = max(t_sensor_j, t_isp_j, t_dram_j)
        thermal_margin = 105.0 - peak_temp

        if peak_temp >= 100.0:
            state = ThermalStateLevel.THERMAL_SHUTDOWN
        elif peak_temp >= 90.0:
            state = ThermalStateLevel.THERMAL_THROTTLE
        elif peak_temp >= 80.0:
            state = ThermalStateLevel.THERMAL_WARNING
        else:
            state = ThermalStateLevel.THERMAL_SAFE

        # Transient Euler simulation over 60 minutes of continuous 16K recording
        # dT/dt = (P_in - (T - T_amb)/R) / C
        c_chassis = 850.0  # J/K chassis aluminum thermal capacitance
        c_sensor = 45.0  # J/K sensor module
        c_isp = 35.0  # J/K ISP module

        time_steps_min = [float(t) for t in range(0, 61, 2)]
        transient_sensor = []
        transient_isp = []
        transient_chassis = []

        curr_t_chassis = ambient_temp_c
        curr_t_sensor = ambient_temp_c
        curr_t_isp = ambient_temp_c

        dt_seconds = 120.0  # 2 minutes step
        for _ in time_steps_min:
            # Chassis heat balance
            q_in_chassis = total_system_power_w
            q_out_chassis = (curr_t_chassis - ambient_temp_c) / r_sink_ambient
            curr_t_chassis += ((q_in_chassis - q_out_chassis) / c_chassis) * (dt_seconds / 60.0)

            # Sensor node
            q_sensor_in = sensor_power_w + adc_power_w
            q_sensor_out = (curr_t_sensor - curr_t_chassis) / r_sensor_jc
            curr_t_sensor += ((q_sensor_in - q_sensor_out) / c_sensor) * (dt_seconds / 60.0)

            # ISP node
            q_isp_in = isp_power_w
            q_isp_out = (curr_t_isp - curr_t_chassis) / r_isp_jc
            curr_t_isp += ((q_isp_in - q_isp_out) / c_isp) * (dt_seconds / 60.0)

            transient_chassis.append(curr_t_chassis)
            transient_sensor.append(curr_t_sensor)
            transient_isp.append(curr_t_isp)

        return ThermalSimulationResult(
            ambient_temp_c=ambient_temp_c,
            total_power_watts=total_system_power_w,
            sensor_junction_temp_c=t_sensor_j,
            isp_junction_temp_c=t_isp_j,
            dram_junction_temp_c=t_dram_j,
            chassis_surface_temp_c=t_chassis_c,
            thermal_state=state,
            thermal_margin_c=thermal_margin,
            transient_time_minutes=time_steps_min,
            transient_sensor_temp_c=transient_sensor,
            transient_isp_temp_c=transient_isp,
            transient_chassis_temp_c=transient_chassis,
        )
