"""
Power distribution system & battery digital twin with internal impedance, discharge curves and runtime scenarios.
"""
from dataclasses import dataclass
from typing import Dict, List


@dataclass
class PowerConsumptionBreakdown:
    sensor_watts: float
    adc_converters_watts: float
    isp_engine_watts: float
    dram_memory_watts: float
    nvme_storage_media_watts: float
    cooling_fans_watts: float
    display_viewfinder_watts: float
    video_outputs_sdi_hdmi_watts: float
    wireless_remote_watts: float
    power_regulation_losses_watts: float
    total_system_watts: float


@dataclass
class BatteryDischargeResult:
    nominal_voltage_v: float
    capacity_wh: float
    capacity_mah: float
    internal_resistance_miliohms: float
    runtime_hours: float
    runtime_minutes: float
    runtime_scenarios: Dict[str, float]  # Minutes in various modes


class PowerSystemModel:
    """
    Models whole-camera electrical loads, DC-DC PMIC conversion efficiency, and lithium-ion/B-Mount battery behavior.
    """

    @staticmethod
    def calculate_power(
        sensor_watts: float,
        adc_watts: float,
        isp_watts: float,
        memory_watts: float,
        storage_watts: float,
        cooling_watts: float = 3.2,
        display_watts: float = 4.5,
        sdi_hdmi_watts: float = 3.8,  # Quad 12G-SDI + HDMI 2.1 PHYs
        wireless_watts: float = 1.2,
        pmic_efficiency: float = 0.91,
        battery_capacity_wh: float = 150.0,  # 150Wh standard cinema B-Mount battery
        battery_voltage_v: float = 28.8,  # 28.8V high-voltage cinema standard
    ) -> tuple[PowerConsumptionBreakdown, BatteryDischargeResult]:
        subtotal_dc_loads = (
            sensor_watts +
            adc_watts +
            isp_watts +
            memory_watts +
            storage_watts +
            cooling_watts +
            display_watts +
            sdi_hdmi_watts +
            wireless_watts
        )

        reg_losses = subtotal_dc_loads * ((1.0 - pmic_efficiency) / pmic_efficiency)
        total_w = subtotal_dc_loads + reg_losses

        breakdown = PowerConsumptionBreakdown(
            sensor_watts=sensor_watts,
            adc_converters_watts=adc_watts,
            isp_engine_watts=isp_watts,
            dram_memory_watts=memory_watts,
            nvme_storage_media_watts=storage_watts,
            cooling_fans_watts=cooling_watts,
            display_viewfinder_watts=display_watts,
            video_outputs_sdi_hdmi_watts=sdi_hdmi_watts,
            wireless_remote_watts=wireless_watts,
            power_regulation_losses_watts=reg_losses,
            total_system_watts=total_w,
        )

        # Battery runtimes
        runtime_h = battery_capacity_wh / max(total_w, 1.0)
        runtime_min = runtime_h * 60.0

        # Runtimes in alternative modes
        scenarios = {
            "16K Cinema RAW (Flagship 60fps)": (battery_capacity_wh / max(total_w * 1.0, 1.0)) * 60.0,
            "16K Visually Lossless (3:1 24fps)": (battery_capacity_wh / max(total_w * 0.72, 1.0)) * 60.0,
            "8K Downsampled DCI (24fps)": (battery_capacity_wh / max(total_w * 0.45, 1.0)) * 60.0,
            "4K High-Speed 120fps": (battery_capacity_wh / max(total_w * 0.65, 1.0)) * 60.0,
            "Standby / Live View EVF Monitoring": (battery_capacity_wh / 14.5) * 60.0,
        }

        mah = (battery_capacity_wh / battery_voltage_v) * 1000.0

        battery_res = BatteryDischargeResult(
            nominal_voltage_v=battery_voltage_v,
            capacity_wh=battery_capacity_wh,
            capacity_mah=mah,
            internal_resistance_miliohms=45.0,
            runtime_hours=runtime_h,
            runtime_minutes=runtime_min,
            runtime_scenarios=scenarios,
        )

        return breakdown, battery_res
