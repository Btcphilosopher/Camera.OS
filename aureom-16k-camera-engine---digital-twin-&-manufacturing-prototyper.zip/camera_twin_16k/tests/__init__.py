"""
Tests package init.
"""
