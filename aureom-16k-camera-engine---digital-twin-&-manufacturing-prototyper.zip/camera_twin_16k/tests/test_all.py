"""
Comprehensive Unit & Integration Test Suite for the AUREOM 16K Camera Digital Twin.
Run directly via:
    python -m unittest camera_twin_16k/tests/test_all.py
"""
import unittest
from pathlib import Path
import math

from ..core.types import (
    Resolution, SensorFormat, CFAType, ShutterArchitecture,
    ADCArchitecture, CodecType, ChassisMaterialType, ThermalCoolingType
)
from ..sensor.sensor_model import SensorModel
from ..optics.optical_system import OpticalSystem
from ..optics.mtf import MTFEngine
from ..pixel.pixel_physics import PixelPhysicsEngine
from ..hdr.hdr_engine import HDREngine
from ..readout.readout_engine import ReadoutEngine
from ..adc.adc_engine import ADCEngine
from ..isp.isp_engine import ISPEngine
from ..codec.codec_engine import CodecEngine
from ..storage.storage_model import StorageSystemModel
from ..memory.memory_system import MemorySystemModel
from ..power.power_system import PowerSystemModel
from ..thermal.thermal_engine import ThermalEngine
from ..mechanical.chassis_model import MechanicalEngine
from ..tolerances.tolerance_engine import ToleranceEngine
from ..manufacturing.mfg_engine import ManufacturingEngine
from ..bom.bom_engine import BOMEngine
from ..costing.cost_breakdown import CostEngine
from ..testing.factory_test import FactoryTestEngine
from ..reliability.reliability_model import ReliabilityEngine
from ..camera.flagship import Aureom16KCinemaCamera
from ..simulation.simulator import CameraSimulator
from ..simulation.monte_carlo_factory import FactoryMonteCarlo
from ..export.report_generator import ReportGenerator


class TestAureom16KDigitalTwin(unittest.TestCase):

    def setUp(self):
        self.camera = Aureom16KCinemaCamera(frame_rate_fps=60.0, bit_depth=16)

    def test_01_sensor_geometry_and_resolution(self):
        """Validates 16K DCI 16384x8640 pixel count and physical large-format sensor dimensions."""
        self.assertEqual(self.camera.sensor.resolution.width, 16384)
        self.assertEqual(self.camera.sensor.resolution.height, 8640)
        self.assertEqual(self.camera.sensor.resolution.total_pixels, 141_557_760)
        self.assertAlmostEqual(self.camera.sensor.resolution.megapixels, 141.56, delta=0.01)

        # 16384 * 3.25um = 53.248 mm
        self.assertAlmostEqual(self.camera.sensor.width_mm, 53.248, places=3)
        # 8640 * 3.25um = 28.080 mm
        self.assertAlmostEqual(self.camera.sensor.height_mm, 28.080, places=3)
        self.assertGreater(self.camera.sensor.diagonal_mm, 60.0)

    def test_02_optical_mtf_and_diffraction(self):
        """Verifies diffraction Airy disk scaling and MTF spatial resolution calculations."""
        mtf_report = MTFEngine.calculate_mtf(
            f_stop=2.8,
            wavelength_m=0.55e-6,
            aberration_factor=0.88,
            sensor_nyquist_lp_mm=self.camera.sensor.nyquist_frequency_lp_per_mm,
        )
        self.assertGreater(self.camera.optical_system.diffraction_cutoff_frequency_lp_mm, 500.0)
        self.assertGreater(mtf_report.mtf50_lp_mm, 80.0)

    def test_03_pixel_physics_and_noise_quadrature(self):
        """Verifies Poisson photon noise, read noise quadrature, and SNR scaling."""
        res = PixelPhysicsEngine.calculate_pixel_response(
            incident_photon_flux_per_sq_um_per_s=500.0,
            exposure_time_s=1.0 / 120.0,
            pixel_area_sq_um=3.25 * 3.25,
            quantum_efficiency=0.82,
            read_noise_e=1.8,
            dark_current_e_per_s=5.0,
            prnu_percent=0.4,
            full_well_capacity_e=48_000.0,
            adc_bit_depth=16,
        )
        self.assertGreater(res.signal_electrons, 10.0)
        self.assertGreater(res.snr_db, 10.0)
        self.assertLess(res.total_noise_e, 48_000.0)

    def test_04_hdr_dynamic_range(self):
        """Verifies dual-gain dynamic range exceeds 14.5 stops."""
        hdr = HDREngine.calculate_hdr(
            full_well_e=48_000.0,
            low_gain_read_noise_e=1.8,
            high_gain_read_noise_e=0.95,
            is_dual_gain_enabled=True,
        )
        self.assertGreaterEqual(hdr.usable_dynamic_range_stops, 14.5)
        self.assertGreaterEqual(hdr.total_dynamic_range_stops, 15.5)

    def test_05_readout_bandwidth_and_rolling_shutter(self):
        """Verifies 16K 60fps 16-bit produces ~135 Gb/s uncompressed bandwidth and ~4.7ms readout duration."""
        readout = ReadoutEngine.calculate_readout(
            resolution=self.camera.sensor.resolution,
            frame_rate_fps=60.0,
            bit_depth=16,
            shutter_arch=ShutterArchitecture.ELECTRONIC_ROLLING,
        )
        self.assertAlmostEqual(readout.raw_gigabits_per_second, 135.90, delta=0.5)
        self.assertGreater(readout.raw_gigabytes_per_second, 15.0)
        self.assertLess(readout.readout_duration_ms, 8.0)

    def test_06_adc_throughput(self):
        """Verifies column-parallel SAR ADC array throughput and power."""
        adc = ADCEngine.calculate_adc_performance(
            bit_depth=16,
            architecture=ADCArchitecture.COLUMN_PARALLEL_SAR,
            total_pixels=self.camera.sensor.resolution.total_pixels,
            sensor_width_columns=self.camera.sensor.resolution.width,
            frame_rate_fps=60.0,
        )
        self.assertEqual(adc.num_parallel_converters, 16384)
        self.assertTrue(adc.is_throughput_sustainable)
        self.assertGreater(adc.effective_number_of_bits_enob, 14.0)

    def test_07_isp_compute_workload(self):
        """Verifies hardware ISP pipeline TFLOPS calculation."""
        isp = ISPEngine.calculate_isp_workload(
            total_pixels=self.camera.sensor.resolution.total_pixels,
            frame_rate_fps=60.0,
            bit_depth=16,
        )
        self.assertGreater(isp.total_compute_tflops, 1.0)
        self.assertLess(isp.pipeline_latency_ms, 20.0)

    def test_08_codec_and_storage(self):
        """Verifies visually lossless compression ratio (3:1) and storage duration."""
        codec = CodecEngine.calculate_codec_metrics(
            raw_bits_per_sec=135.89e9,
            raw_pixels_per_sec=141_557_760 * 60,
            codec_type=CodecType.VISUALLY_LOSSLESS_RAW,
            custom_compression_ratio=3.0,
        )
        self.assertGreater(codec.encoded_gigabytes_per_second, 5.0)
        storage = StorageSystemModel()
        durations = storage.calculate_recording_durations(codec.encoded_gigabytes_per_second * (1024**3))
        # 8TB drive gives >20 minutes
        dur_8tb = next(d for d in durations if d.capacity_tb == 8.0)
        self.assertGreater(dur_8tb.recording_minutes, 20.0)

    def test_09_memory_subsystem_dram_bandwidth(self):
        """Verifies HBM3 / LPDDR5X bus load is below safe threshold."""
        mem = MemorySystemModel()
        res = mem.calculate_memory_performance(
            total_pixels=self.camera.sensor.resolution.total_pixels,
            frame_rate_fps=60.0,
            bit_depth=16,
            isp_dram_bandwidth_gb_s=25.0,
            codec_dram_bandwidth_gb_s=8.5,
        )
        self.assertTrue(res.is_bandwidth_adequate)
        self.assertLess(res.dram_bus_utilization_percent, 85.0)

    def test_10_thermal_dissipation(self):
        """Verifies lumped thermal resistance network and safe steady-state temperatures."""
        thermal = ThermalEngine.simulate_thermal(
            ambient_temp_c=25.0,
            sensor_power_w=8.5,
            adc_power_w=3.8,
            isp_power_w=14.5,
            memory_power_w=6.2,
            storage_power_w=4.2,
            power_reg_loss_w=4.0,
            display_wireless_w=5.5,
            cooling_type=ThermalCoolingType.DUAL_BLOWER_VAPOR_CHAMBER,
            fan_airflow_cfm=6.5,
        )
        self.assertLess(thermal.sensor_junction_temp_c, 80.0)
        self.assertLess(thermal.chassis_surface_temp_c, 48.0)
        self.assertGreater(thermal.thermal_margin_c, 15.0)

    def test_11_mechanical_and_tolerances(self):
        """Verifies chassis weight, CoG, and Monte Carlo tolerance pass yield."""
        mech = MechanicalEngine.calculate_mechanics()
        self.assertGreater(mech.total_camera_body_mass_kg, 1.5)
        self.assertLess(mech.total_camera_body_mass_kg, 4.0)

        tol = ToleranceEngine.run_monte_carlo_tolerances(num_simulations=500)
        self.assertGreater(tol.assembly_pass_yield_percent, 90.0)

    def test_12_manufacturing_bom_and_economics(self):
        """Verifies complete BOM calculation, direct labor, UMC and MSRP."""
        mfg = ManufacturingEngine.calculate_manufacturing_summary()
        bom = BOMEngine.calculate_bom_summary()
        cost = CostEngine.calculate_camera_economics(
            bom_cost_usd=bom["total_bom_cost_usd"],
            direct_labor_usd=mfg["total_direct_labor_cost_usd"],
        )
        self.assertGreater(bom["total_bom_cost_usd"], 5000.0)
        self.assertGreater(cost.total_unit_manufacturing_cost_usd, 7000.0)
        self.assertGreater(cost.suggested_msrp_usd, 15000.0)

    def test_13_end_to_end_simulation_and_export(self):
        """Verifies full camera twin simulation and file exports."""
        sim = CameraSimulator(self.camera)
        state = sim.run()
        self.assertTrue(state.is_spec_satisfied)

        out_dir = Path("test_output")
        ReportGenerator.export_all_files(state, out_dir)
        self.assertTrue((out_dir / "camera_report.json").exists())
        self.assertTrue((out_dir / "camera_report.md").exists())
        self.assertTrue((out_dir / "camera_summary.csv").exists())
        self.assertTrue((out_dir / "thermal_curve.csv").exists())
        self.assertTrue((out_dir / "bandwidth_report.csv").exists())
        self.assertTrue((out_dir / "factory_yield.csv").exists())
        self.assertTrue((out_dir / "bom.csv").exists())


if __name__ == "__main__":
    unittest.main()
