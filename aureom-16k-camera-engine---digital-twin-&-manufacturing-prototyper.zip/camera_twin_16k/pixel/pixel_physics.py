"""
Pixel physics equations, electron generation, noise breakdown and SNR calculations.
"""
from dataclasses import dataclass
import math
from typing import Dict, Tuple


@dataclass
class PixelPhysicsResult:
    incident_photons: float
    signal_electrons: float
    shot_noise_e: float
    read_noise_e: float
    dark_noise_e: float
    prnu_noise_e: float
    quantisation_noise_e: float
    total_noise_e: float
    snr_linear: float
    snr_db: float
    is_saturated: bool
    dynamic_range_stops_instantaneous: float


class PixelPhysicsEngine:
    """
    Computes rigorous photon-to-electron generation and multi-source noise decomposition.
    """

    @staticmethod
    def calculate_pixel_response(
        incident_photon_flux_per_sq_um_per_s: float,
        exposure_time_s: float,
        pixel_area_sq_um: float,
        quantum_efficiency: float,
        read_noise_e: float,
        dark_current_e_per_s: float,
        prnu_percent: float,
        full_well_capacity_e: float,
        adc_bit_depth: int = 16,
    ) -> PixelPhysicsResult:
        # Photons arriving at pixel surface
        photons = incident_photon_flux_per_sq_um_per_s * exposure_time_s * pixel_area_sq_um

        # Electron conversion via Quantum Efficiency
        ideal_signal_e = photons * quantum_efficiency
        dark_e = dark_current_e_per_s * exposure_time_s

        total_collected_e = ideal_signal_e + dark_e
        is_saturated = total_collected_e >= full_well_capacity_e
        actual_signal_e = min(total_collected_e, full_well_capacity_e)

        # Noise component breakdown
        # 1. Poisson shot noise of optical signal + dark signal
        shot_noise_e = math.sqrt(max(actual_signal_e, 0.0))

        # 2. Dark current shot noise
        dark_noise_e = math.sqrt(max(dark_e, 0.0))

        # 3. Read noise (amplifier thermal + flicker 1/f noise)
        rn_e = max(read_noise_e, 0.01)

        # 4. PRNU (Photo-response non-uniformity spatial variance)
        prnu_noise_e = actual_signal_e * (prnu_percent / 100.0)

        # 5. ADC Quantisation noise: q / sqrt(12), where q = FWC / 2^bits
        lsb_electrons = full_well_capacity_e / float(2 ** adc_bit_depth)
        quantisation_noise_e = lsb_electrons / math.sqrt(12.0)

        # Total uncorrelated noise (quadrature sum)
        total_noise_e = math.sqrt(
            shot_noise_e ** 2 +
            rn_e ** 2 +
            dark_noise_e ** 2 +
            prnu_noise_e ** 2 +
            quantisation_noise_e ** 2
        )

        # Signal-to-Noise Ratio (SNR)
        effective_signal = max(actual_signal_e - dark_e, 0.0)
        snr_linear = effective_signal / max(total_noise_e, 1e-6)
        snr_db = 20.0 * math.log10(max(snr_linear, 1e-6))

        # Instantaneous DR (ratio of saturated signal to instantaneous floor noise)
        dr_instantaneous_stops = math.log2(max(full_well_capacity_e / max(total_noise_e, rn_e), 1.0))

        return PixelPhysicsResult(
            incident_photons=photons,
            signal_electrons=actual_signal_e,
            shot_noise_e=shot_noise_e,
            read_noise_e=rn_e,
            dark_noise_e=dark_noise_e,
            prnu_noise_e=prnu_noise_e,
            quantisation_noise_e=quantisation_noise_e,
            total_noise_e=total_noise_e,
            snr_linear=snr_linear,
            snr_db=snr_db,
            is_saturated=is_saturated,
            dynamic_range_stops_instantaneous=dr_instantaneous_stops,
        )
