"""
AUREOM CAMERA ENGINE - 16K PROFESSIONAL CAMERA DIGITAL TWIN
Canonical Python Scientific & Manufacturing Twin
"""

__version__ = "1.0.0"
__product__ = "AUREOM CAMERA ENGINE"
__subsystem__ = "AUREOM 16K DIGITAL TWIN"

from .camera.camera_model import CameraModel
from .camera.flagship import Aureom16KCinemaCamera
from .simulation.simulator import CameraSimulator
from .simulation.monte_carlo_factory import FactoryMonteCarlo
from .scenarios.scenario_engine import ScenarioEngine

__all__ = [
    "CameraModel",
    "Aureom16KCinemaCamera",
    "CameraSimulator",
    "FactoryMonteCarlo",
    "ScenarioEngine",
    "__version__",
    "__product__",
    "__subsystem__",
]
