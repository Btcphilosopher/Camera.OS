"""
Sensor physical model, format definitions, and quantum efficiency curves.
"""
from dataclasses import dataclass, field
import math
from typing import Dict, Optional, Tuple
from ..core.types import SensorFormat, CFAType, Resolution, RES_16K_DCI
from ..core.constants import REF_WAVELENGTH_M


@dataclass
class SensorModel:
    """
    Physical CMOS Image Sensor Model.
    Can be parameterized either by pixel pitch + resolution or authoritative physical dimensions.
    """
    resolution: Resolution = field(default_factory=lambda: RES_16K_DCI)
    pixel_pitch_um: float = 3.25  # micrometers
    sensor_format: SensorFormat = SensorFormat.LARGE_FORMAT
    cfa_type: CFAType = CFAType.BAYER_RGGB
    quantum_efficiency_peak: float = 0.82  # 82% peak QE at 530nm
    dark_current_e_per_s_at_20c: float = 1.2  # electrons/pixel/sec at 20 deg C
    read_noise_low_gain_e: float = 1.8  # e- RMS read noise at base ISO
    read_noise_high_gain_e: float = 0.95  # e- RMS read noise at dual native ISO
    full_well_capacity_e: float = 48_000.0  # electrons full-well capacity
    conversion_gain_uv_per_e: float = 45.0  # microvolts per electron
    saturation_voltage_mv: float = 850.0  # mV
    prnu_percent: float = 0.45  # Photo-Response Non-Uniformity (%)
    dsnu_e: float = 0.35  # Dark Signal Non-Uniformity (e-)
    global_shutter_overhead_factor: float = 1.0  # 1.0 for Rolling, 1.25 for GS (storage node area penalty)
    active_pixel_fill_factor: float = 0.88  # 88% with BSI microlenses

    # Optional explicit physical dimensions override
    override_width_mm: Optional[float] = None
    override_height_mm: Optional[float] = None

    @property
    def width_mm(self) -> float:
        if self.override_width_mm is not None:
            return self.override_width_mm
        return (self.resolution.width * self.pixel_pitch_um) / 1000.0

    @property
    def height_mm(self) -> float:
        if self.override_height_mm is not None:
            return self.override_height_mm
        return (self.resolution.height * self.pixel_pitch_um) / 1000.0

    @property
    def diagonal_mm(self) -> float:
        return math.sqrt(self.width_mm ** 2 + self.height_mm ** 2)

    @property
    def active_area_sq_mm(self) -> float:
        return self.width_mm * self.height_mm

    @property
    def pixel_area_sq_um(self) -> float:
        return self.pixel_pitch_um ** 2

    @property
    def nyquist_frequency_lp_per_mm(self) -> float:
        """Sensor native Nyquist spatial frequency in line pairs per mm (1 / (2 * pitch_mm))."""
        pitch_mm = self.pixel_pitch_um / 1000.0
        return 1.0 / (2.0 * pitch_mm)

    @property
    def dynamic_range_db(self) -> float:
        """Sensor theoretical dynamic range in dB: 20 * log10(FWC / ReadNoise)."""
        rn = max(self.read_noise_low_gain_e, 0.1)
        return 20.0 * math.log10(self.full_well_capacity_e / rn)

    @property
    def dynamic_range_stops(self) -> float:
        """Sensor theoretical dynamic range in exposure stops: log2(FWC / ReadNoise)."""
        rn = max(self.read_noise_low_gain_e, 0.1)
        return math.log2(self.full_well_capacity_e / rn)

    def dark_current_at_temp(self, temp_c: float) -> float:
        """Dark current doubles approximately every 6-8 deg C (Arrhenius approximation)."""
        delta_t = temp_c - 20.0
        doublings = delta_t / 7.0
        return self.dark_current_e_per_s_at_20c * (2.0 ** doublings)

    def get_effective_optical_resolution_mp(self, optical_mtf50_lp_mm: float) -> float:
        """
        Calculates delivered effective optical resolution taking optical MTF limit into account.
        Effective MP is constrained by min(sensor Nyquist, optical limit).
        """
        sensor_nyq = self.nyquist_frequency_lp_per_mm
        limiting_freq = min(sensor_nyq, optical_mtf50_lp_mm * 1.4)
        eff_width = (self.width_mm * limiting_freq * 2.0)
        eff_height = (self.height_mm * limiting_freq * 2.0)
        eff_pixels = min(eff_width * eff_height, float(self.resolution.total_pixels))
        return eff_pixels / 1_000_000.0
