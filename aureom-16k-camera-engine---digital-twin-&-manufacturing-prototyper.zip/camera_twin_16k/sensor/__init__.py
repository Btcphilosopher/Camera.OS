"""
Sensor package init.
"""
from .sensor_model import SensorModel

__all__ = ["SensorModel"]
