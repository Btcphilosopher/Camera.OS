"""
Rolling shutter vs Global shutter physics, line timing duration, flash band skew and pixel trade-offs.
"""
from dataclasses import dataclass
from ..core.types import ShutterArchitecture


@dataclass
class ShutterModel:
    architecture: ShutterArchitecture = ShutterArchitecture.ELECTRONIC_ROLLING
    line_readout_time_us: float = 0.55  # microseconds per horizontal row
    global_shutter_parasitic_light_sensitivity_db: float = -92.0  # PLS suppression
    storage_node_dark_current_multiplier: float = 1.35  # Additional leakage on in-pixel storage node
    full_well_capacity_penalty_percent: float = 22.0  # 22% FWC reduction due to 6T storage capacitor area

    def calculate_rolling_shutter_duration_ms(self, vertical_lines: int) -> float:
        if self.architecture == ShutterArchitecture.ELECTRONIC_GLOBAL:
            return 0.0  # True instantaneous frame capture
        # Total sensor scan time from top line to bottom line
        duration_us = vertical_lines * self.line_readout_time_us
        return duration_us / 1000.0  # milliseconds
