"""
Shutter package init.
"""
from .shutter_model import ShutterModel

__all__ = ["ShutterModel"]
