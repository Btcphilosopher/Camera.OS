"""
Memory hierarchy system: Stacked HBM3 / LPDDR5X DRAM bandwidth, frame buffer depth, DMA channels, and latency.
"""
from dataclasses import dataclass


@dataclass
class MemorySystemResult:
    frame_buffer_size_mb: float
    triple_buffer_capacity_mb: float
    required_dram_bandwidth_gb_s: float
    installed_dram_bandwidth_gb_s: float
    dram_bus_utilization_percent: float
    buffer_underrun_headroom_frames: int
    memory_subsystem_power_watts: float
    is_bandwidth_adequate: bool


class MemorySystemModel:
    """
    Simulates high-bandwidth memory (HBM3/3e on 2.5D interposer or multi-channel LPDDR5X).
    """

    def __init__(
        self,
        technology: str = "HBM3 2.5D Stacked Memory (2-Die Interposer)",
        installed_capacity_gb: float = 32.0,
        installed_bandwidth_gb_s: float = 820.0,
    ):
        self.technology = technology
        self.installed_capacity_gb = installed_capacity_gb
        self.installed_bandwidth_gb_s = installed_bandwidth_gb_s

    def calculate_memory_performance(
        self,
        total_pixels: int,
        frame_rate_fps: float,
        bit_depth: int,
        isp_dram_bandwidth_gb_s: float,
        codec_dram_bandwidth_gb_s: float,
    ) -> MemorySystemResult:
        bytes_per_frame = (total_pixels * bit_depth) / 8.0
        frame_buffer_mb = bytes_per_frame / (1024.0 ** 2)
        triple_buffer_mb = frame_buffer_mb * 3.0

        raw_stream_gb_s = (bytes_per_frame * frame_rate_fps) / (1024.0 ** 3)

        # Aggregate memory bus demand: Sensor DMA In + ISP Processing + Codec Fetch + Video Output Scan
        total_dram_demand_gb_s = raw_stream_gb_s + isp_dram_bandwidth_gb_s + codec_dram_bandwidth_gb_s + 4.5

        bus_utilization = (total_dram_demand_gb_s / max(self.installed_bandwidth_gb_s, 1.0)) * 100.0

        # Memory power: ~6-8 mW per GB/s of active data traffic + static standby
        power_w = (total_dram_demand_gb_s * 0.0075) + 2.8

        headroom_frames = int((self.installed_capacity_gb * 1024.0) / max(frame_buffer_mb, 1.0))
        is_adequate = bus_utilization <= 85.0  # Safe real-time ceiling

        return MemorySystemResult(
            frame_buffer_size_mb=frame_buffer_mb,
            triple_buffer_capacity_mb=triple_buffer_mb,
            required_dram_bandwidth_gb_s=total_dram_demand_gb_s,
            installed_dram_bandwidth_gb_s=self.installed_bandwidth_gb_s,
            dram_bus_utilization_percent=bus_utilization,
            buffer_underrun_headroom_frames=headroom_frames,
            memory_subsystem_power_watts=power_w,
            is_bandwidth_adequate=is_adequate,
        )
