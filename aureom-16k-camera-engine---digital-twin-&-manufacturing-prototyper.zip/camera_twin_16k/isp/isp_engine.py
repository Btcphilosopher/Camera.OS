"""
Image Signal Processor (ISP) performance, pipeline stages, latency, ops/pixel and power modeling.
"""
from dataclasses import dataclass
from typing import Dict, List


@dataclass
class ISPStageInfo:
    name: str
    operations_per_pixel: float
    memory_reads_per_pixel: float
    memory_writes_per_pixel: float
    pipeline_latency_lines: float
    power_weight: float


ISP_STAGES: List[ISPStageInfo] = [
    ISPStageInfo("Black Level Subtraction & Linearization", 4.0, 1.0, 1.0, 1.0, 0.05),
    ISPStageInfo("Dynamic Defect Pixel Correction (DPC)", 28.0, 3.0, 1.0, 3.0, 0.08),
    ISPStageInfo("Wavelet / Bilateral RAW Noise Reduction", 65.0, 5.0, 1.0, 8.0, 0.16),
    ISPStageInfo("Lens Shading & Vignetting Compensation", 12.0, 1.5, 1.0, 2.0, 0.06),
    ISPStageInfo("High-Precision Cinema Demosaicing (AHD/Directional)", 110.0, 9.0, 3.0, 16.0, 0.24),
    ISPStageInfo("Auto White Balance & Channel Gains", 6.0, 3.0, 3.0, 1.0, 0.05),
    ISPStageInfo("3x3 Color Matrix & Gamut Transform (ACES/Wide Gamut)", 18.0, 3.0, 3.0, 1.0, 0.08),
    ISPStageInfo("Dual-Gain HDR Fusion & Highlight Reconstruction", 45.0, 6.0, 3.0, 4.0, 0.12),
    ISPStageInfo("Logarithmic Curve & Tone Mapping (AureomLog)", 22.0, 3.0, 3.0, 2.0, 0.07),
    ISPStageInfo("Edge Sharpening & Detail Synthesis", 36.0, 5.0, 3.0, 5.0, 0.10),
    ISPStageInfo("3D-LUT Color Science & Final Color Space Encode", 48.0, 4.0, 3.0, 2.0, 0.11),
    ISPStageInfo("Chroma Subsampling & Output Formatter", 10.0, 3.0, 2.0, 1.0, 0.04),
]


@dataclass
class ISPPerformanceResult:
    total_operations_per_pixel: float
    total_memory_bandwidth_gb_per_sec: float
    total_compute_tflops: float
    pipeline_latency_ms: float
    isp_power_watts: float
    stages: List[Dict[str, float]]


class ISPEngine:
    """
    Simulates high-throughput computational imaging pipeline for 16K cinema workloads.
    """

    @staticmethod
    def calculate_isp_workload(
        total_pixels: int,
        frame_rate_fps: float,
        bit_depth: int = 16,
        asic_efficiency_tflops_per_watt: float = 2.4,
    ) -> ISPPerformanceResult:
        pixels_per_sec = float(total_pixels) * float(frame_rate_fps)
        bytes_per_sample = bit_depth / 8.0

        total_ops_per_pixel = sum(s.operations_per_pixel for s in ISP_STAGES)
        total_ops_per_sec = pixels_per_sec * total_ops_per_pixel
        total_tflops = total_ops_per_sec / 1e12

        total_mem_traffic_bytes_per_pixel = sum(
            (s.memory_reads_per_pixel + s.memory_writes_per_pixel) * bytes_per_sample
            for s in ISP_STAGES
        )
        # On-chip SRAM line buffers reduce external DRAM traffic by approx 75%
        external_dram_factor = 0.25
        total_mem_bandwidth_gb_s = (pixels_per_sec * total_mem_traffic_bytes_per_pixel * external_dram_factor) / (1024 ** 3)

        total_latency_lines = sum(s.pipeline_latency_lines for s in ISP_STAGES)
        # Frame height approximation
        line_time_ms = (1.0 / max(frame_rate_fps, 1.0)) / 8640.0 * 1000.0
        pipeline_latency_ms = total_latency_lines * line_time_ms

        # ISP silicon power: dynamic compute power + internal SRAM clocking
        isp_power_w = (total_tflops / max(asic_efficiency_tflops_per_watt, 0.1)) + 4.5

        stages_summary = [
            {
                "name": s.name,
                "ops_per_pixel": s.operations_per_pixel,
                "tflops": (pixels_per_sec * s.operations_per_pixel) / 1e12,
            }
            for s in ISP_STAGES
        ]

        return ISPPerformanceResult(
            total_operations_per_pixel=total_ops_per_pixel,
            total_memory_bandwidth_gb_per_sec=total_mem_bandwidth_gb_s,
            total_compute_tflops=total_tflops,
            pipeline_latency_ms=pipeline_latency_ms,
            isp_power_watts=isp_power_w,
            stages=stages_summary,
        )
