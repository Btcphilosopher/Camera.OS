"""
Active & passive thermal cooling management system.
"""
from dataclasses import dataclass
from ..core.types import ThermalCoolingType


@dataclass
class CoolingSystemModel:
    cooling_type: ThermalCoolingType = ThermalCoolingType.DUAL_BLOWER_VAPOR_CHAMBER
    max_fan_rpm: float = 4800.0
    current_fan_rpm: float = 3200.0
    acoustic_noise_db_at_1m: float = 19.5  # Below whisper-quiet soundstage threshold (20 dBA)
    power_consumption_watts: float = 3.2

    @property
    def airflow_cfm(self) -> float:
        return (self.current_fan_rpm / self.max_fan_rpm) * 9.5
