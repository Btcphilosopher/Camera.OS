"""
Cooling package init.
"""
from .cooling_system import CoolingSystemModel

__all__ = ["CoolingSystemModel"]
