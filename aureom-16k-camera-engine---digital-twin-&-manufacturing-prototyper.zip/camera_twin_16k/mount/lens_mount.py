"""
Interchangeable Cinema Lens Mount Digital Twin (LPL, PL, EF, Custom Cinema Mounts).
"""
from dataclasses import dataclass


@dataclass
class LensMountSpecification:
    name: str = "ARRI LPL (Large Positive Lock) Mount"
    flange_focal_distance_mm: float = 44.000  # mm
    throat_inner_diameter_mm: float = 62.000  # mm
    outer_diameter_mm: float = 84.000  # mm
    flange_depth_tolerance_um: float = 5.0  # +/- 5 micrometers tolerance
    electronic_pins: int = 12  # Cooke /i3 and LDS-2 lens metadata protocol
    locking_mechanism: str = "Positive Cam-Lock Ring with Stainless Steel Shims"

    def is_compatible_with_sensor_diagonal(self, sensor_diagonal_mm: float) -> bool:
        """Returns True if the throat diameter and image circle clear the sensor active diagonal."""
        return self.throat_inner_diameter_mm >= (sensor_diagonal_mm + 4.0)


STANDARD_MOUNTS = {
    "LPL": LensMountSpecification("ARRI LPL Large Format Mount", 44.0, 62.0, 84.0, 5.0, 12),
    "PL": LensMountSpecification("Standard Cinema PL Mount", 52.0, 54.0, 78.0, 5.0, 8),
    "SONY_E": LensMountSpecification("Sony E-Mount Mirrorless", 18.0, 46.1, 65.0, 8.0, 10),
    "CANON_RF": LensMountSpecification("Canon RF Mount", 20.0, 54.0, 72.0, 8.0, 12),
}
