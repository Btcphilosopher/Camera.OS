"""
Cinema lens mechanics and optical performance wrapper.
"""
from dataclasses import dataclass
from typing import Optional
from ..optics.optical_system import OpticalSystem


@dataclass
class CinemaLensModel:
    model_name: str = "Aureom Cine Prime 50mm T1.5 LF"
    focal_length_mm: float = 50.0
    t_stop_max: float = 1.5
    f_stop_max: float = 1.4
    mount_type: str = "LPL / PL Mount"
    image_circle_mm: float = 60.0
    front_diameter_mm: float = 114.0
    weight_g: float = 1450.0
    aberration_factor: float = 0.88  # 0.88 optical transfer quality

    def to_optical_system(self, current_t_stop: float = 2.8, focus_dist_m: float = 2.5) -> OpticalSystem:
        f_stop = current_t_stop * (self.f_stop_max / self.t_stop_max)
        return OpticalSystem(
            focal_length_mm=self.focal_length_mm,
            f_stop=f_stop,
            t_stop=current_t_stop,
            focus_distance_m=focus_dist_m,
            image_circle_diameter_mm=self.image_circle_mm,
        )
