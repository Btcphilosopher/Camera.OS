"""
Manufacturing operations workflow, step lead times, station yields and work-in-progress tracking.
"""
from dataclasses import dataclass
from typing import List


@dataclass
class ManufacturingStep:
    step_number: int
    name: str
    workstation: str
    cycle_time_minutes: float
    labor_rate_usd_per_hour: float
    first_pass_yield_percent: float


MANUFACTURING_PROCESS_FLOW: List[ManufacturingStep] = [
    ManufacturingStep(1, "5-Axis CNC Precision Chassis Milling", "CNC Machining Center", 85.0, 95.0, 98.2),
    ManufacturingStep(2, "Surface Anodizing & Laser Etching", "Chemical Surface Treatment", 35.0, 65.0, 99.1),
    ManufacturingStep(3, "SMT High-Density PCB Assembly", "Cleanroom SMT Line", 45.0, 110.0, 97.5),
    ManufacturingStep(4, "Stacked Sensor Wafer Die-Attach & Wirebond", "Class 100 Cleanroom Cell", 55.0, 145.0, 96.0),
    ManufacturingStep(5, "Optical Low-Pass Filter & IR-Cut Glass Bonding", "Class 100 Optical Station", 30.0, 130.0, 98.5),
    ManufacturingStep(6, "Vapor Chamber & Active Cooling Thermal Assembly", "Mechanical Integration", 25.0, 85.0, 99.4),
    ManufacturingStep(7, "Main Board & IO Interconnect Harnessing", "Assembly Line A", 40.0, 75.0, 98.8),
    ManufacturingStep(8, "Stainless Steel Lens Mount Flange Alignment", "Laser Interferometer Station", 35.0, 120.0, 97.2),
    ManufacturingStep(9, "Automated Factory Calibration (Black/Color/PRNU)", "Dark Chamber Automated Rig", 60.0, 90.0, 99.0),
    ManufacturingStep(10, "14-Point Factory QA & Burn-in Chamber", "Environmental Chamber Test", 120.0, 80.0, 96.5),
    ManufacturingStep(11, "Final Cosmetic Inspection & Cleanroom Pack", "Packaging Station", 20.0, 55.0, 99.8),
]


class ManufacturingEngine:
    @staticmethod
    def calculate_manufacturing_summary() -> dict:
        total_time_min = sum(s.cycle_time_minutes for s in MANUFACTURING_PROCESS_FLOW)
        total_labor_cost = sum((s.cycle_time_minutes / 60.0) * s.labor_rate_usd_per_hour for s in MANUFACTURING_PROCESS_FLOW)

        overall_yield = 1.0
        for s in MANUFACTURING_PROCESS_FLOW:
            overall_yield *= (s.first_pass_yield_percent / 100.0)

        return {
            "total_manufacturing_time_hours": total_time_min / 60.0,
            "total_direct_labor_cost_usd": total_labor_cost,
            "cumulative_first_pass_yield_percent": overall_yield * 100.0,
            "steps": [
                {
                    "step": s.step_number,
                    "name": s.name,
                    "workstation": s.workstation,
                    "time_min": s.cycle_time_minutes,
                    "labor_usd": (s.cycle_time_minutes / 60.0) * s.labor_rate_usd_per_hour,
                    "yield_pct": s.first_pass_yield_percent,
                }
                for s in MANUFACTURING_PROCESS_FLOW
            ],
        }
