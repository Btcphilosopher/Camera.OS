"""
High Dynamic Range (HDR) architectures: Dual Gain Architecture (DGO / DCG), Multi-exposure Staggered HDR, and single-exposure tone mapping.
"""
from dataclasses import dataclass
import math


@dataclass
class HDRPerformanceResult:
    total_dynamic_range_stops: float
    usable_dynamic_range_stops: float
    highlight_headroom_stops: float
    shadow_headroom_stops: float
    readout_line_overhead_factor: float
    motion_artifact_risk: str  # 'NONE' for Dual-Gain instantaneous, 'MODERATE' for multi-exposure


class HDREngine:
    """
    Evaluates HDR sensor architectures and usable dynamic range.
    """

    @staticmethod
    def calculate_hdr(
        full_well_e: float,
        low_gain_read_noise_e: float,
        high_gain_read_noise_e: float,
        is_dual_gain_enabled: bool = True,
    ) -> HDRPerformanceResult:
        if is_dual_gain_enabled:
            # Dual Gain Architecture captures both High-Gain (low read noise in shadows)
            # and Low-Gain (maximum full-well in highlights) simultaneously in a single exposure.
            rn_effective = min(high_gain_read_noise_e, low_gain_read_noise_e)
            fw_effective = full_well_e
            total_dr_stops = math.log2(fw_effective / max(rn_effective, 0.05))
            # Usable DR takes SNR > 1 (0dB) cut-off into account, approx 0.8 stop margin
            usable_dr_stops = max(total_dr_stops - 0.75, 1.0)
            highlight_stops = math.log2(fw_effective / (fw_effective * 0.18))
            shadow_stops = total_dr_stops - highlight_stops
            return HDRPerformanceResult(
                total_dynamic_range_stops=total_dr_stops,
                usable_dynamic_range_stops=usable_dr_stops,
                highlight_headroom_stops=highlight_stops,
                shadow_headroom_stops=shadow_stops,
                readout_line_overhead_factor=1.15,
                motion_artifact_risk="NONE (Instantaneous Dual Gain Sampling)",
            )
        else:
            total_dr_stops = math.log2(full_well_e / max(low_gain_read_noise_e, 0.1))
            usable_dr_stops = max(total_dr_stops - 0.8, 1.0)
            return HDRPerformanceResult(
                total_dynamic_range_stops=total_dr_stops,
                usable_dynamic_range_stops=usable_dr_stops,
                highlight_headroom_stops=6.5,
                shadow_headroom_stops=total_dr_stops - 6.5,
                readout_line_overhead_factor=1.0,
                motion_artifact_risk="NONE (Standard Linear Mode)",
            )
