"""
Examples package init.
"""
from .aureom_16k import main

__all__ = ["main"]
