"""
Executable engineering verification script for the Aureom 16K Cinema Digital Twin.
Run directly via:
    python -m camera_twin_16k.examples.aureom_16k
"""
import sys
from pathlib import Path
from ..camera.flagship import Aureom16KCinemaCamera
from ..simulation.simulator import CameraSimulator
from ..export.report_generator import ReportGenerator
from ..scenarios.scenario_engine import ScenarioEngine


def main():
    print("=" * 80)
    print("      AUREOM CAMERA ENGINE — 16K CINEMA DIGITAL TWIN SIMULATOR")
    print("    Canon / Sony / RED / ARRI-Class Professional Architecture Prototyper")
    print("=" * 80)

    # 1. Instantiate the Flagship Camera Digital Twin
    camera = Aureom16KCinemaCamera(frame_rate_fps=60.0, bit_depth=16)
    print(f"\n[INIT] Initializing Digital Twin Model: {camera.model_name}")
    print(f"[OPTICS] Lens: {camera.lens.model_name} at T{camera.optical_system.t_stop:.1f}")
    print(f"[SENSOR] Matrix: {camera.sensor.resolution.width}x{camera.sensor.resolution.height} ({camera.sensor.resolution.megapixels:.1f} MP), Pitch: {camera.sensor.pixel_pitch_um} um")
    print(f"[EXPOSURE] Timing: {camera.exposure.frame_rate_fps} fps @ {camera.exposure.shutter_angle_deg} deg shutter")

    # 2. Execute Full System Physics Simulation
    print("\n[SIM] Executing end-to-end physics, thermal, and manufacturing pipeline...")
    sim = CameraSimulator(camera)
    state = sim.run()

    # 3. Print Console Verification Summary
    print("\n" + "=" * 80)
    print("                      SYSTEM VERIFICATION METRICS")
    print("=" * 80)
    print(f"  • Usable Dynamic Range:        {state.hdr_result.usable_dynamic_range_stops:.2f} Stops (Total: {state.hdr_result.total_dynamic_range_stops:.2f} Stops)")
    print(f"  • Base Read Noise (Floor):     {state.sensor.read_noise_low_gain_e:.2f} e- RMS (High Gain: {state.sensor.read_noise_high_gain_e:.2f} e-)")
    print(f"  • Raw Sensor Readout Stream:   {state.readout_result.raw_gigabits_per_second:.2f} Gb/s ({state.readout_result.raw_gigabytes_per_second:.2f} GB/s)")
    print(f"  • Visually Lossless Bitrate:   {state.codec_result.encoded_megabytes_per_second:.1f} MB/s ({state.codec_result.encoded_gigabytes_per_second:.2f} GB/s)")
    print(f"  • ISP Processing Load:         {state.isp_result.total_compute_tflops:.2f} TFLOPS (Latency: {state.isp_result.pipeline_latency_ms:.2f} ms)")
    print(f"  • DRAM Memory Bus Traffic:     {state.memory_result.required_dram_bandwidth_gb_s:.1f} GB/s (Bus Load: {state.memory_result.dram_bus_utilization_percent:.1f}%)")
    print(f"  • Total Electrical Power:      {state.power_breakdown.total_system_watts:.1f} Watts (Battery Life: {state.battery_result.runtime_minutes:.1f} min)")
    print(f"  • Sensor Junction Temperature: {state.thermal_result.sensor_junction_temp_c:.1f}°C ({state.thermal_result.thermal_state.value})")
    print(f"  • Camera Body Mass:            {state.mechanical_result.total_camera_body_mass_kg:.2f} kg (Chassis: {state.chassis_material.value})")
    print(f"  • Unit Manufacturing Cost:     ${state.cost_economics.total_unit_manufacturing_cost_usd:,.2f} USD (MSRP: ${state.cost_economics.suggested_msrp_usd:,.2f} USD)")
    print(f"  • Spec Status:                 {'PASS (ALL GATES SATISFIED)' if state.is_spec_satisfied else 'FAIL'}")

    # 4. Run Factory Monte Carlo Simulation (1,000 virtual factory units)
    print("\n[MONTE CARLO] Simulating 1,000-unit factory manufacturing variance run...")
    factory_res = sim.run_factory_monte_carlo(num_units=1000)
    print(f"  • Factory First-Pass Yield:    {factory_res.yield_percent:.2f}% (Scrap Rate: {factory_res.scrap_rate_percent:.2f}%)")
    print(f"  • Mean Dynamic Range:          {factory_res.mean_dynamic_range_stops:.2f} Stops [Min: {factory_res.min_dynamic_range_stops:.2f}, Max: {factory_res.max_dynamic_range_stops:.2f}]")
    print(f"  • Mean Unit Cost:              ${factory_res.mean_unit_cost_usd:,.2f} ± ${factory_res.cost_std_usd:.2f}")

    # 5. Run Frame Rate Sweep
    print("\n[SWEEP] Running frame rate capability sweep (24 to 240 fps)...")
    sweep_results = sim.run_frame_rate_sweep([24.0, 30.0, 48.0, 60.0, 120.0, 240.0])
    for r in sweep_results:
        achievable_str = "ACHIEVABLE" if r["is_achievable"] else "EXCEEDS BUS LIMIT"
        print(f"  - {r['fps']:5.1f} fps -> Raw: {r['raw_gb_s']:5.2f} GB/s | DRAM: {r['dram_bandwidth_gb_s']:5.1f} GB/s | Power: {r['total_power_w']:5.1f} W | Temp: {r['peak_sensor_temp_c']:4.1f}°C [{achievable_str}]")

    # 6. Export Reports & CSV Data
    output_path = Path("output")
    print(f"\n[EXPORT] Generating full reports and CSV datasets in '{output_path.resolve()}'...")
    ReportGenerator.export_all_files(state, output_path, factory_res)
    print("  ✓ output/camera_report.json")
    print("  ✓ output/camera_report.md")
    print("  ✓ output/camera_summary.csv")
    print("  ✓ output/thermal_curve.csv")
    print("  ✓ output/bandwidth_report.csv")
    print("  ✓ output/factory_yield.csv")
    print("  ✓ output/bom.csv")

    print("\n" + "=" * 80)
    print("        AUREOM 16K DIGITAL TWIN SIMULATION COMPLETED SUCCESSFULLY")
    print("=" * 80)


if __name__ == "__main__":
    main()
