"""
Scenario engine: Loads declarative camera configuration scenarios (16K Cinema Flagship, 8K High-Speed, Extreme Desert 50°C, Studio Eco-Power, Global Shutter Action) and simulates full twin.
"""
from dataclasses import dataclass
from typing import Dict, Any, Optional
from ..camera.camera_model import CameraModel, CameraSimulationState
from ..camera.flagship import Aureom16KCinemaCamera
from ..core.types import (
    RES_16K_DCI, RES_8K_DCI, RES_4K_DCI, CodecType,
    ShutterArchitecture, ChassisMaterialType, ThermalCoolingType
)


SCENARIO_PRESETS: Dict[str, Dict[str, Any]] = {
    "16K Cinema Flagship 60fps": {
        "description": "Standard 16K DCI 60fps visually lossless RAW recording under standard 25°C ambient.",
        "resolution": RES_16K_DCI,
        "fps": 60.0,
        "bit_depth": 16,
        "codec": CodecType.VISUALLY_LOSSLESS_RAW,
        "compression_ratio": 3.0,
        "ambient_c": 25.0,
        "shutter": ShutterArchitecture.ELECTRONIC_ROLLING,
        "battery_wh": 150.0,
    },
    "16K Global Shutter Extreme Action": {
        "description": "16K capture with 6T Global Shutter for zero flash-band and zero rolling skew on high-speed VFX rigs.",
        "resolution": RES_16K_DCI,
        "fps": 48.0,
        "bit_depth": 14,
        "codec": CodecType.VISUALLY_LOSSLESS_RAW,
        "compression_ratio": 3.5,
        "ambient_c": 28.0,
        "shutter": ShutterArchitecture.ELECTRONIC_GLOBAL,
        "battery_wh": 150.0,
    },
    "8K High-Speed 120fps Broadcast": {
        "description": "8K DCI high-speed sports & slow-motion capture at 120fps with ProRes 4444 XQ encode.",
        "resolution": RES_8K_DCI,
        "fps": 120.0,
        "bit_depth": 12,
        "codec": CodecType.PRORES_4444_XQ,
        "compression_ratio": 4.5,
        "ambient_c": 30.0,
        "shutter": ShutterArchitecture.ELECTRONIC_ROLLING,
        "battery_wh": 150.0,
    },
    "Extreme Desert Heat 50°C Stress Test": {
        "description": "Thermal stress test at 50°C equipment environment testing dual vapor chamber thermal dissipation.",
        "resolution": RES_16K_DCI,
        "fps": 60.0,
        "bit_depth": 16,
        "codec": CodecType.VISUALLY_LOSSLESS_RAW,
        "compression_ratio": 3.0,
        "ambient_c": 50.0,
        "shutter": ShutterArchitecture.ELECTRONIC_ROLLING,
        "battery_wh": 150.0,
    },
    "Studio Eco-Power 24fps Narrative": {
        "description": "Quiet-set 24fps cinema narrative mode optimizing acoustic fan noise (<18dBA) and battery endurance.",
        "resolution": RES_16K_DCI,
        "fps": 24.0,
        "bit_depth": 16,
        "codec": CodecType.MATHEMATICALLY_LOSSLESS_RAW,
        "compression_ratio": 1.8,
        "ambient_c": 20.0,
        "shutter": ShutterArchitecture.ELECTRONIC_ROLLING,
        "battery_wh": 190.0,
    },
}


class ScenarioEngine:
    @staticmethod
    def run_preset(preset_name: str) -> tuple[CameraModel, CameraSimulationState]:
        config = SCENARIO_PRESETS.get(preset_name, SCENARIO_PRESETS["16K Cinema Flagship 60fps"])
        cam = Aureom16KCinemaCamera(
            resolution=config["resolution"],
            frame_rate_fps=config["fps"],
            bit_depth=config["bit_depth"],
            shutter_arch=config["shutter"],
            codec_type=config["codec"],
            ambient_temp_c=config["ambient_c"],
        )
        cam.custom_compression_ratio = config["compression_ratio"]
        cam.battery_capacity_wh = config["battery_wh"]
        state = cam.simulate()
        return cam, state
