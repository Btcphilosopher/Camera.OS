"""
Radiometric photon pipeline: Scene -> Lens transmission -> Aperture -> Sensor Illuminance -> Photon arrival flux.
"""
from dataclasses import dataclass
import math
from .scene import SyntheticScene, SceneType, SCENE_PRESETS
from ..core.constants import SPEED_OF_LIGHT, PLANCK_CONSTANT, REF_WAVELENGTH_M


@dataclass
class PhotonArrivalResult:
    sensor_plane_illuminance_lux: float  # lux on image plane
    sensor_irradiance_w_per_m2: float  # W / m^2
    photon_flux_per_sq_um_per_s: float  # photons / (um^2 · s)
    single_photon_energy_joules: float  # E = h * c / lambda


class PhotonPipeline:
    """
    Simulates optical radiometry from scene luminance through lens transmission & aperture to focal plane.
    """

    @staticmethod
    def simulate_optical_flux(
        scene_luminance_cd_m2: float,
        t_stop: float,
        lens_transmission: float = 0.90,
        nd_filter_optical_density: float = 0.0,
        wavelength_m: float = REF_WAVELENGTH_M,
    ) -> PhotonArrivalResult:
        # ND filter attenuation factor: 10^(-OD)
        nd_factor = 10.0 ** (-nd_filter_optical_density)

        # Image plane illuminance E_sensor = (pi * L * transmission * nd) / (4 * T^2)
        # Using T-stop: E_sensor = (pi * L * nd) / (4 * T^2)
        eff_t_stop = max(t_stop, 0.5)
        sensor_illuminance_lux = (math.pi * scene_luminance_cd_m2 * nd_factor * lens_transmission) / (4.0 * (eff_t_stop ** 2))

        # Approximate luminous efficacy of 550nm green light: 683 lumens/Watt
        sensor_irradiance_w_per_m2 = sensor_illuminance_lux / 683.0

        # Energy per photon E = h * c / lambda (in Joules)
        e_photon = (PLANCK_CONSTANT * SPEED_OF_LIGHT) / wavelength_m

        # Total photons arriving per m^2 per second
        photons_per_m2_s = sensor_irradiance_w_per_m2 / e_photon

        # Convert to photons per micrometer^2 per second (1 m^2 = 1e12 um^2)
        photon_flux_per_sq_um_s = photons_per_m2_s / 1e12

        return PhotonArrivalResult(
            sensor_plane_illuminance_lux=sensor_illuminance_lux,
            sensor_irradiance_w_per_m2=sensor_irradiance_w_per_m2,
            photon_flux_per_sq_um_per_s=photon_flux_per_sq_um_s,
            single_photon_energy_joules=e_photon,
        )
