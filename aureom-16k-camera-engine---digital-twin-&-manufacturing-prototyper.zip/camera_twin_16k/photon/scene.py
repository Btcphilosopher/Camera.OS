"""
Synthetic scene radiometry generator supporting daylight, tungsten, low light, HDR, specular, skin tones, foliage, architecture, and test charts.
"""
from dataclasses import dataclass
from enum import Enum
from typing import Dict, List, Tuple


class SceneType(str, Enum):
    DAYLIGHT_SUNNY = "Daylight Direct Sun (100,000 lux)"
    DAYLIGHT_OVERCAST = "Daylight Overcast Sky (10,000 lux)"
    CINEMA_STUDIO_KEY = "Cinema Studio Key (1,500 lux)"
    TUNGSTEN_WARM_INTERIOR = "Tungsten Warm Interior (300 lux)"
    LOW_LIGHT_STREET = "Low-Light Night Street (10 lux)"
    EXTREME_LOW_LIGHT_MOON = "Extreme Low-Light Moonlight (0.1 lux)"
    HIGH_DYNAMIC_RANGE_EXTREME = "High Dynamic Range Interior/Exterior (18 Stops)"
    SPECULAR_HIGHLIGHT_STUDIO = "Specular Highlights / Jewelry / Glass"
    SKIN_TONE_PORTRAIT = "Studio Skin-Tone & Textile Chart"
    FOLIAGE_LANDSCAPE = "High Spatial Frequency Foliage"
    ARCHITECTURE_HIGH_CONTRAST = "Urban Architecture & Geometric Grids"
    SIEMENS_STAR_TEST_CHART = "Virtual Siemens Star Resolution Target"
    ISO_12233_TEST_CHART = "Virtual ISO-12233 Edge Target"


@dataclass
class SyntheticScene:
    scene_type: SceneType = SceneType.CINEMA_STUDIO_KEY
    illuminance_lux: float = 1500.0  # lumens / m^2
    color_temp_kelvin: float = 5600.0  # 5600K daylight or 3200K tungsten
    scene_dynamic_range_stops: float = 14.5
    highlight_reflectance: float = 0.90
    midtones_18_percent_reflectance: float = 0.18
    shadow_reflectance: float = 0.015

    @property
    def midtone_luminance_cd_m2(self) -> float:
        """Approximate diffuse reflected luminance L = (E * R) / pi in cd/m^2 (nits)."""
        import math
        return (self.illuminance_lux * self.midtones_18_percent_reflectance) / math.pi

    @property
    def highlight_luminance_cd_m2(self) -> float:
        import math
        return (self.illuminance_lux * self.highlight_reflectance) / math.pi

    @property
    def shadow_luminance_cd_m2(self) -> float:
        import math
        return (self.illuminance_lux * self.shadow_reflectance) / math.pi


SCENE_PRESETS: Dict[SceneType, SyntheticScene] = {
    SceneType.DAYLIGHT_SUNNY: SyntheticScene(SceneType.DAYLIGHT_SUNNY, 100_000.0, 5600.0, 15.0),
    SceneType.DAYLIGHT_OVERCAST: SyntheticScene(SceneType.DAYLIGHT_OVERCAST, 10_000.0, 6500.0, 12.0),
    SceneType.CINEMA_STUDIO_KEY: SyntheticScene(SceneType.CINEMA_STUDIO_KEY, 1_500.0, 5600.0, 14.0),
    SceneType.TUNGSTEN_WARM_INTERIOR: SyntheticScene(SceneType.TUNGSTEN_WARM_INTERIOR, 300.0, 3200.0, 13.0),
    SceneType.LOW_LIGHT_STREET: SyntheticScene(SceneType.LOW_LIGHT_STREET, 10.0, 4000.0, 16.0),
    SceneType.EXTREME_LOW_LIGHT_MOON: SyntheticScene(SceneType.EXTREME_LOW_LIGHT_MOON, 0.1, 4100.0, 10.0),
    SceneType.HIGH_DYNAMIC_RANGE_EXTREME: SyntheticScene(SceneType.HIGH_DYNAMIC_RANGE_EXTREME, 20_000.0, 5600.0, 18.0),
    SceneType.SPECULAR_HIGHLIGHT_STUDIO: SyntheticScene(SceneType.SPECULAR_HIGHLIGHT_STUDIO, 5_000.0, 5600.0, 17.0),
    SceneType.SKIN_TONE_PORTRAIT: SyntheticScene(SceneType.SKIN_TONE_PORTRAIT, 1_200.0, 4800.0, 13.5),
    SceneType.FOLIAGE_LANDSCAPE: SyntheticScene(SceneType.FOLIAGE_LANDSCAPE, 25_000.0, 5600.0, 14.0),
    SceneType.ARCHITECTURE_HIGH_CONTRAST: SyntheticScene(SceneType.ARCHITECTURE_HIGH_CONTRAST, 50_000.0, 5600.0, 16.5),
    SceneType.SIEMENS_STAR_TEST_CHART: SyntheticScene(SceneType.SIEMENS_STAR_TEST_CHART, 2_000.0, 5000.0, 10.0),
    SceneType.ISO_12233_TEST_CHART: SyntheticScene(SceneType.ISO_12233_TEST_CHART, 2_000.0, 5000.0, 10.0),
}
