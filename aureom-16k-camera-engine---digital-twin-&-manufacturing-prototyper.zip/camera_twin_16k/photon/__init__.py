"""
Photon package init.
"""
from .scene import SyntheticScene, SceneType, SCENE_PRESETS
from .photon_pipeline import PhotonPipeline, PhotonArrivalResult

__all__ = ["SyntheticScene", "SceneType", "SCENE_PRESETS", "PhotonPipeline", "PhotonArrivalResult"]
