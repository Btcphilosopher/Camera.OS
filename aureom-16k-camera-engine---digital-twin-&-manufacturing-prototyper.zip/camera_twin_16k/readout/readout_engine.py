"""
Readout engine: High-speed column parallel data lanes, MIPI CSI-2 / SLVS-EC lane count, clock frequencies, and raw sensor bandwidth.
"""
from dataclasses import dataclass
from ..core.types import Resolution, ShutterArchitecture


@dataclass
class ReadoutEngineResult:
    pixels_per_frame: int
    bits_per_frame: int
    raw_bits_per_second: float
    raw_gigabits_per_second: float
    raw_gigabytes_per_second: float
    slvs_ec_lanes_required_at_5gbps: int
    readout_duration_ms: float
    is_frame_rate_achievable: bool


class ReadoutEngine:
    """
    Simulates high-speed column bus readout, lane serializer requirements and line scan timings.
    """

    @staticmethod
    def calculate_readout(
        resolution: Resolution,
        frame_rate_fps: float,
        bit_depth: int,
        shutter_arch: ShutterArchitecture,
        max_sensor_lane_bandwidth_gbps: float = 640.0,  # 128 lanes x 5.0 Gbps SLVS-EC or sub-LVDS
    ) -> ReadoutEngineResult:
        pixels_per_frame = resolution.total_pixels
        bits_per_frame = pixels_per_frame * bit_depth

        raw_bits_per_sec = float(bits_per_frame) * float(frame_rate_fps)
        raw_gbps = raw_bits_per_sec / 1_000_000_000.0
        raw_gb_per_sec = raw_bits_per_sec / (8.0 * (1024 ** 3))

        # Lane count calculation based on 5.0 Gbps per SLVS-EC lane with 8b/10b or 64b/66b encoding
        effective_lane_speed_gbps = 4.8
        lanes_required = int((raw_gbps / effective_lane_speed_gbps) + 0.999)

        # Line readout duration
        if shutter_arch == ShutterArchitecture.ELECTRONIC_GLOBAL:
            readout_ms = (1.0 / max(frame_rate_fps, 1.0)) * 1000.0 * 0.45
        else:
            # High speed stacked column readout (e.g. 1.1us per line at 16K)
            readout_ms = (resolution.height * 0.00065)  # in milliseconds

        is_achievable = raw_gbps <= max_sensor_lane_bandwidth_gbps

        return ReadoutEngineResult(
            pixels_per_frame=pixels_per_frame,
            bits_per_frame=bits_per_frame,
            raw_bits_per_second=raw_bits_per_sec,
            raw_gigabits_per_second=raw_gbps,
            raw_gigabytes_per_second=raw_gb_per_sec,
            slvs_ec_lanes_required_at_5gbps=lanes_required,
            readout_duration_ms=readout_ms,
            is_frame_rate_achievable=is_achievable,
        )
