"""
Physical and engineering constants for optical and sensor physics.
"""
import math

# Speed of light in vacuum (m/s)
SPEED_OF_LIGHT = 299_792_458.0

# Planck's constant (J·s)
PLANCK_CONSTANT = 6.62607015e-34

# Boltzmann constant (J/K)
BOLTZMANN_CONSTANT = 1.380649e-23

# Elementary charge (Coulombs)
ELEMENTARY_CHARGE = 1.602176634e-19

# Standard visible green wavelength for optical reference (m and nm)
REF_WAVELENGTH_M = 550.0e-9
REF_WAVELENGTH_NM = 550.0

# Standard room temperature in Kelvin
STANDARD_TEMP_K = 293.15  # 20 deg C

# Standard thermal voltage at 20 deg C (V)
THERMAL_VOLTAGE_20C = 0.02526
