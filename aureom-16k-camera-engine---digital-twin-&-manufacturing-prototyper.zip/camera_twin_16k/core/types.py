"""
Core types, enums and standard structures for AUREOM CAMERA ENGINE.
"""
from dataclasses import dataclass, field
from enum import Enum, auto
from typing import Dict, List, Optional, Tuple, Any


class SensorFormat(str, Enum):
    SUPER_35 = "Super 35"
    APS_C = "APS-C"
    FULL_FRAME = "Full Frame"
    LARGE_FORMAT = "Large Format 65mm"
    CUSTOM = "Custom"


class CFAType(str, Enum):
    BAYER_RGGB = "Bayer RGGB"
    BAYER_BGGR = "Bayer BGGR"
    QUAD_BAYER = "Quad Bayer"
    MONOCHROME = "Monochrome (No CFA)"
    THREE_SENSOR_PRISM = "3-Sensor Beam Splitter Prism"
    CUSTOM_RGBW = "RGBW Custom"


class ShutterArchitecture(str, Enum):
    ELECTRONIC_ROLLING = "Electronic Rolling Shutter"
    ELECTRONIC_GLOBAL = "Electronic Global Shutter (Charge-Domain 5T/6T)"
    MECHANICAL_ROTARY = "Mechanical Rotary Disc Shutter"


class ADCArchitecture(str, Enum):
    COLUMN_PARALLEL_SAR = "Column-Parallel SAR ADC (14/16-bit)"
    COLUMN_PARALLEL_SS = "Column-Parallel Single-Slope ADC"
    PIXEL_LEVEL_ADC = "Pixel-Level Stitched ADC"
    DUAL_GAIN_ADC = "Dual-Gain Parallel ADC (High DR)"


class ComputeArchitecture(str, Enum):
    CUSTOM_ASIC = "Custom Hardware ISP ASIC (Dedicated Fixed-Function & VPU)"
    GPU_HBM = "Embedded High-Bandwidth GPU Compute"
    FPGA_ACCELERATOR = "Multi-Die Cinema FPGA Array"
    HETEROGENEOUS_NPU = "Heterogeneous ASIC + DSP + NPU Pipeline"


class CodecType(str, Enum):
    UNCOMPRESSED_RAW = "Uncompressed Cinema RAW"
    VISUALLY_LOSSLESS_RAW = "Aureom RAW Cinema (Visually Lossless 3:1)"
    MATHEMATICALLY_LOSSLESS_RAW = "Lossless RAW Entropy (1.8:1)"
    PRORES_4444_XQ = "Cinema 4:4:4 12-bit Intra"
    HEVC_PRO_INTRA = "H.265 / AV1 Pro 4:2:2 10-bit"


class ChassisMaterialType(str, Enum):
    AEROSPACE_ALUMINUM_6061 = "Aerospace Aluminum 6061-T6"
    AEROSPACE_ALUMINUM_7075 = "Aerospace Aluminum 7075-T6"
    MAGNESIUM_ALLOY_AZ91D = "Magnesium Alloy AZ91D Die-Cast"
    TITANIUM_GRADE_5 = "Titanium Grade 5 (Ti-6Al-4V)"
    CARBON_FIBER_PEEK = "Toray Carbon-Fiber / PEEK Composite"


class ThermalCoolingType(str, Enum):
    PASSIVE_CONDUCTION = "Passive Heat Pipe & Chassis Conduction"
    ACTIVE_QUIET_FAN = "Active Low-Vibration Magnetic Levitation Blower"
    DUAL_BLOWER_VAPOR_CHAMBER = "Sealed Dual Vapor Chamber + Active Blower"
    LIQUID_MICRO_CHANNEL = "Internal Closed-Loop Micro-Channel Cooling"


class ThermalStateLevel(str, Enum):
    THERMAL_SAFE = "THERMAL_SAFE"
    THERMAL_WARNING = "THERMAL_WARNING"
    THERMAL_THROTTLE = "THERMAL_THROTTLE"
    THERMAL_SHUTDOWN = "THERMAL_SHUTDOWN"


class TestResultStatus(str, Enum):
    PASS = "PASS"
    WARNING = "WARNING"
    FAIL = "FAIL"


@dataclass
class Resolution:
    width: int
    height: int
    name: str = "Custom"

    @property
    def total_pixels(self) -> int:
        return self.width * self.height

    @property
    def megapixels(self) -> float:
        return self.total_pixels / 1_000_000.0

    @property
    def aspect_ratio(self) -> float:
        return self.width / max(self.height, 1)

    def __str__(self) -> str:
        return f"{self.width}x{self.height} ({self.megapixels:.1f} MP)"


# Predefined resolutions
RES_16K_DCI = Resolution(16384, 8640, "16K DCI (1.89:1)")
RES_16K_UHD = Resolution(15360, 8640, "16K UHD (16:9)")
RES_12K_DCI = Resolution(12288, 6480, "12K DCI (1.89:1)")
RES_8K_DCI = Resolution(8192, 4320, "8K DCI (1.89:1)")
RES_6K_DCI = Resolution(6144, 3240, "6K DCI (1.89:1)")
RES_4K_DCI = Resolution(4096, 2160, "4K DCI (1.89:1)")
