"""
Exceptions, unit conversion helpers and structured logging for AUREOM CAMERA ENGINE.
"""
import logging
from typing import Any, Dict


class CameraEngineError(Exception):
    """Base exception for all camera twin calculations."""
    pass


class SpecificationViolationError(CameraEngineError):
    """Raised when an engineering hard constraint is breached."""
    pass


class ThermalRunawayError(CameraEngineError):
    """Raised when thermal dissipation is physically inadequate for operating wattage."""
    pass


class BandwidthExceededError(CameraEngineError):
    """Raised when data bus or memory bus saturates beyond physical maximum."""
    pass


def get_logger(name: str = "camera_twin_16k") -> logging.Logger:
    logger = logging.getLogger(name)
    if not logger.handlers:
        handler = logging.StreamHandler()
        formatter = logging.Formatter(
            "[%(asctime)s] [%(levelname)s] [%(name)s] %(message)s",
            datefmt="%Y-%m-%d %H:%M:%S"
        )
        handler.setFormatter(formatter)
        logger.addHandler(handler)
        logger.setLevel(logging.INFO)
    return logger


def bytes_to_gb(b: float) -> float:
    return b / (1024 ** 3)


def bits_to_gbps(bits: float) -> float:
    return bits / 1_000_000_000.0


def bytes_to_tb_per_hour(bytes_per_sec: float) -> float:
    return (bytes_per_sec * 3600.0) / (1024 ** 4)


def kelvin_to_celsius(k: float) -> float:
    return k - 273.15


def celsius_to_kelvin(c: float) -> float:
    return c + 273.15
