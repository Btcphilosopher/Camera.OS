"""
Exposure engine: Shutter angle / speed, ISO gain stages (dual native ISO), ND filters, and signal amplification.
"""
from dataclasses import dataclass
import math
from typing import Dict, List, Tuple


@dataclass
class ExposureConfiguration:
    frame_rate_fps: float = 24.0
    shutter_angle_deg: float = 180.0  # 180 deg cinema standard (11.25 to 360)
    iso: float = 800.0  # Operating ISO
    base_iso_low: float = 800.0  # Base native ISO circuit 1
    base_iso_high: float = 3200.0  # Dual native ISO circuit 2
    nd_filter_stops: float = 0.0  # Internal optical ND stops (0 to 7 stops: Clear, 0.3, 0.6, 0.9, 1.2, 1.5, 1.8, 2.1)
    exposure_compensation_ev: float = 0.0

    @property
    def exposure_time_s(self) -> float:
        """Integration time in seconds = (shutter_angle / 360) * (1 / fps)."""
        return (self.shutter_angle_deg / 360.0) * (1.0 / max(self.frame_rate_fps, 1.0))

    @property
    def is_using_high_conversion_gain_circuit(self) -> bool:
        """Returns True if operating ISO switches to the second high-conversion-gain analog capacitor/FET."""
        return self.iso >= self.base_iso_high

    @property
    def active_native_base_iso(self) -> float:
        return self.base_iso_high if self.is_using_high_conversion_gain_circuit else self.base_iso_low

    @property
    def analog_gain_multiplier(self) -> float:
        """Analog voltage amplification factor relative to active base ISO."""
        base = self.active_native_base_iso
        return max(self.iso / base, 1.0)

    @property
    def analog_gain_db(self) -> float:
        return 20.0 * math.log10(self.analog_gain_multiplier)

    @property
    def nd_optical_density(self) -> float:
        """ND optical density OD = stops * log10(2) approx stops * 0.301."""
        return self.nd_filter_stops * 0.30103
