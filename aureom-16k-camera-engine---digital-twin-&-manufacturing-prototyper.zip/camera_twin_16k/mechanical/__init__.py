"""
Mechanical package init.
"""
from .chassis_model import MechanicalEngine, MechanicalChassisResult, CentreOfGravity

__all__ = ["MechanicalEngine", "MechanicalChassisResult", "CentreOfGravity"]
