"""
Comprehensive camera noise source decomposition.
"""
from dataclasses import dataclass
import math


@dataclass
class NoiseSourceBreakdown:
    photon_shot_noise_e: float
    dark_current_shot_noise_e: float
    pixel_reset_kTC_noise_e: float  # Removed via Correlated Double Sampling (CDS)
    amplifier_thermal_noise_e: float
    flicker_1_over_f_noise_e: float
    prnu_spatial_noise_e: float
    dsnu_spatial_noise_e: float
    adc_quantisation_noise_e: float
    total_temporal_noise_e: float
    total_spatial_noise_e: float
    total_combined_noise_e: float


class NoiseEngine:
    @staticmethod
    def compute_noise_budget(
        signal_electrons: float,
        dark_electrons: float,
        read_noise_rms_e: float,
        prnu_percent: float = 0.45,
        dsnu_e: float = 0.35,
        bit_depth: int = 16,
        full_well_e: float = 48000.0,
    ) -> NoiseSourceBreakdown:
        shot_e = math.sqrt(max(signal_electrons, 0.0))
        dark_shot_e = math.sqrt(max(dark_electrons, 0.0))
        # Reset kTC noise is eliminated by true CDS in 4T/5T pixels
        ktc_e = 0.0

        amp_thermal_e = read_noise_rms_e * 0.75
        flicker_e = read_noise_rms_e * 0.25

        prnu_e = signal_electrons * (prnu_percent / 100.0)
        dsnu_val = dsnu_e

        lsb_e = full_well_e / float(2 ** bit_depth)
        adc_q_e = lsb_e / math.sqrt(12.0)

        temporal_sq = (shot_e ** 2) + (dark_shot_e ** 2) + (read_noise_rms_e ** 2) + (adc_q_e ** 2)
        spatial_sq = (prnu_e ** 2) + (dsnu_val ** 2)

        tot_temporal = math.sqrt(temporal_sq)
        tot_spatial = math.sqrt(spatial_sq)
        tot_combined = math.sqrt(temporal_sq + spatial_sq)

        return NoiseSourceBreakdown(
            photon_shot_noise_e=shot_e,
            dark_current_shot_noise_e=dark_shot_e,
            pixel_reset_kTC_noise_e=ktc_e,
            amplifier_thermal_noise_e=amp_thermal_e,
            flicker_1_over_f_noise_e=flicker_e,
            prnu_spatial_noise_e=prnu_e,
            dsnu_spatial_noise_e=dsnu_val,
            adc_quantisation_noise_e=adc_q_e,
            total_temporal_noise_e=tot_temporal,
            total_spatial_noise_e=tot_spatial,
            total_combined_noise_e=tot_combined,
        )
